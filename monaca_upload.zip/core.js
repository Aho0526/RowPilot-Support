// ===============================================================
// スペースインベーダー コアエンジン (core.js)
// ※ 基本的に編集不要ですが、コードを読んで改造してもOK！
// ===============================================================

(function() {
    'use strict';

    let canvas = document.getElementById("gameCanvas");
    let ctx = canvas ? canvas.getContext("2d") : null;

    // キャンバス基準解像度 (480 x 560)
    const V_WIDTH = 480;
    const V_HEIGHT = 560;

    function ensureCanvas() {
        if (!canvas) {
            canvas = document.getElementById("gameCanvas");
            if (canvas) {
                ctx = canvas.getContext("2d");
                canvas.width = V_WIDTH;
                canvas.height = V_HEIGHT;
            }
        } else if (!ctx) {
            ctx = canvas.getContext("2d");
            canvas.width = V_WIDTH;
            canvas.height = V_HEIGHT;
        }
        return !!(canvas && ctx);
    }

    if (canvas) {
        canvas.width = V_WIDTH;
        canvas.height = V_HEIGHT;
    }

    // 安全な数値取得ヘルパー
    function safeNum(val, min, max, defaultVal) {
        const n = Number(val);
        if (isNaN(n)) return defaultVal;
        return Math.max(min, Math.min(max, n));
    }

    // ─────────────────────────────────────────────
    // レトロサウンドエンジン (Web Audio API)
    // ─────────────────────────────────────────────
    let audioCtx = null;
    function initAudio() {
        if (!audioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) audioCtx = new AudioContext();
        }
        if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
    }

    const Sound = {
        enabled: false, // デフォルトでミュート
        walkStep: 0,
        walkPitches: [58, 52, 46, 40], // 4音行進ステップ

        playWalk() {
            if (!this.enabled || !audioCtx) return;
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = "square";
            osc.frequency.setValueAtTime(this.walkPitches[this.walkStep % 4], audioCtx.currentTime);
            this.walkStep++;
            gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.08);
        },

        playShoot() {
            if (!this.enabled || !audioCtx) return;
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = "sawtooth";
            osc.frequency.setValueAtTime(900, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(100, audioCtx.currentTime + 0.15);
            gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.15);
        },

        playInvaderHit() {
            if (!this.enabled || !audioCtx) return;
            // ノイズバースト
            const bufferSize = audioCtx.sampleRate * 0.09;
            const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
            const data = buffer.getChannelData(0);
            for (let i = 0; i < bufferSize; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.2));
            }
            const noise = audioCtx.createBufferSource();
            noise.buffer = buffer;
            const gain = audioCtx.createGain();
            gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
            noise.connect(gain);
            gain.connect(audioCtx.destination);
            noise.start();
        },

        playPlayerHit() {
            if (!this.enabled || !audioCtx) return;
            const bufferSize = audioCtx.sampleRate * 0.4;
            const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
            const data = buffer.getChannelData(0);
            for (let i = 0; i < bufferSize; i++) {
                data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
            }
            const noise = audioCtx.createBufferSource();
            noise.buffer = buffer;
            const gain = audioCtx.createGain();
            gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
            noise.connect(gain);
            gain.connect(audioCtx.destination);
            noise.start();
        },

        ufoOsc: null,
        ufoGain: null,
        startUFO() {
            if (!this.enabled || !audioCtx || this.ufoOsc) return;
            this.ufoOsc = audioCtx.createOscillator();
            this.ufoGain = audioCtx.createGain();
            this.ufoOsc.type = "sawtooth";
            this.ufoGain.gain.setValueAtTime(0.07, audioCtx.currentTime);
            
            // ピロピロ変調
            const now = audioCtx.currentTime;
            this.ufoOsc.frequency.setValueAtTime(450, now);
            for (let i = 0; i < 200; i++) {
                this.ufoOsc.frequency.setValueAtTime((i % 2 === 0 ? 550 : 450), now + i * 0.06);
            }
            this.ufoOsc.connect(this.ufoGain);
            this.ufoGain.connect(audioCtx.destination);
            this.ufoOsc.start();
        },

        stopUFO() {
            if (this.ufoOsc) {
                try {
                    this.ufoOsc.stop();
                    this.ufoOsc.disconnect();
                } catch(e) {}
                this.ufoOsc = null;
            }
        },

        playUFOHit() {
            this.stopUFO();
            if (!this.enabled || !audioCtx) return;
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = "triangle";
            const now = audioCtx.currentTime;
            osc.frequency.setValueAtTime(600, now);
            osc.frequency.linearRampToValueAtTime(1200, now + 0.12);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(now + 0.2);
        }
    };

    // ─────────────────────────────────────────────
    // スプライト（ドット絵）定義
    // ─────────────────────────────────────────────
    // 1: ピクセル描画, 0: 透明
    const SPRITES = {
        // イカ型 (Squid) 8x8
        squid: [
            [
                "00011000",
                "00111100",
                "01111110",
                "11011011",
                "11111111",
                "00100100",
                "01011010",
                "10100101"
            ],
            [
                "00011000",
                "00111100",
                "01111110",
                "11011011",
                "11111111",
                "01011010",
                "10000001",
                "01000010"
            ]
        ],
        // カニ型 (Crab) 11x8
        crab: [
            [
                "00100000100",
                "00010001000",
                "00111111100",
                "01101110110",
                "11111111111",
                "10111111101",
                "10100000101",
                "00011011000"
            ],
            [
                "00100000100",
                "10010001001",
                "10111111101",
                "11101110111",
                "11111111111",
                "01111111110",
                "00100000100",
                "01000000010"
            ]
        ],
        // タコ型 (Octopus) 12x8
        octopus: [
            [
                "000011110000",
                "011111111110",
                "111111111111",
                "111001100111",
                "111111111111",
                "000110011000",
                "001101101100",
                "110000000011"
            ],
            [
                "000011110000",
                "011111111110",
                "111111111111",
                "111001100111",
                "111111111111",
                "001100001100",
                "011011110110",
                "000100001000"
            ]
        ],
        // プレイヤー砲台 (Player Cannon) 13x8
        player: [
            "0000001000000",
            "0000011100000",
            "0000011100000",
            "0111111111110",
            "1111111111111",
            "1111111111111",
            "1111111111111",
            "1111111111111"
        ],
        // UFO (Mystery Ship) 16x7
        ufo: [
            "0000011111100000",
            "0001111111111000",
            "0011111111111100",
            "0110110110110110",
            "1111111111111111",
            "0001110001110000",
            "0000100000100000"
        ],
        // 敵撃破爆発 (Explosion) 11x8
        explosion: [
            "00001000100",
            "01000101000",
            "00100000100",
            "11000000011",
            "11000000011",
            "00100000100",
            "01000101000",
            "00001000100"
        ],
        // プレイヤーやられ爆発 2コマ
        playerBlow: [
            [
                "0001001000100",
                "0100100010010",
                "0010001000100",
                "1000100010001",
                "0100000000010",
                "1001000001001",
                "0010010100100",
                "0100000000010"
            ],
            [
                "0100010001000",
                "0010001000100",
                "1001000001001",
                "0100000000010",
                "0001001000100",
                "0100000000010",
                "1000100010001",
                "0010001000100"
            ]
        ]
    };

    // 敵キャラ(1コマ形式)の2コマ目を自動生成: 下3行を1ドット右にずらして足踏みを表現
    const WALKING_KEYS = ["squid", "crab", "octopus"];
    function makeWalkFrame(pattern) {
        const legStart = Math.max(0, pattern.length - 3);
        return pattern.map((row, i) => {
            if (i < legStart) return row;
            return "0" + row.slice(0, row.length - 1);
        });
    }

    // 動的スプライト取得ヘルパー（GameConfig.sprites で上書き可能）
    function getSprite(key, frame = 0) {
        if (window.GameConfig && window.GameConfig.sprites && window.GameConfig.sprites[key]) {
            const custom = window.GameConfig.sprites[key];
            if (Array.isArray(custom) && custom.length > 0) {
                if (Array.isArray(custom[0])) {
                    return custom[frame % custom.length] || custom[0];
                }
                if (WALKING_KEYS.includes(key) && frame % 2 === 1) {
                    return makeWalkFrame(custom);
                }
                return custom;
            }
        }
        const def = SPRITES[key];
        if (Array.isArray(def) && Array.isArray(def[0])) {
            return def[frame % def.length];
        }
        return def;
    }

    // スプライトの幅と高さを動的計算
    function getSpriteDimensions(pattern, pixelSize = 2) {
        if (!pattern || !pattern.length) return { width: 16, height: 16 };
        let maxCols = 0;
        for (let r = 0; r < pattern.length; r++) {
            if (pattern[r] && pattern[r].length > maxCols) {
                maxCols = pattern[r].length;
            }
        }
        return {
            width: Math.max(8, maxCols * pixelSize),
            height: Math.max(8, pattern.length * pixelSize)
        };
    }

    // ピクセルパターン描画関数（堅牢版: 欠損行や空文字でも停止しない）
    function drawPixelPattern(pattern, x, y, pixelSize, color) {
        if (!pattern || !pattern.length) return;
        ctx.fillStyle = color;
        for (let r = 0; r < pattern.length; r++) {
            const row = pattern[r];
            if (!row) continue;
            for (let c = 0; c < row.length; c++) {
                if (row[c] === '1') {
                    ctx.fillRect(x + c * pixelSize, y + r * pixelSize, pixelSize, pixelSize);
                }
            }
        }
    }

    // ─────────────────────────────────────────────
    // 防壁（トーチカ・バンカー）ピクセルモデル
    // ─────────────────────────────────────────────
    // 22 x 16 ドットのドーム形状
    const BUNKER_TEMPLATE = [
        "00001111111111110000",
        "00011111111111111000",
        "00111111111111111100",
        "01111111111111111110",
        "11111111111111111111",
        "11111111111111111111",
        "11111111111111111111",
        "11111111111111111111",
        "11111111111111111111",
        "11111100000000111111",
        "11111000000000011111",
        "11110000000000001111",
        "11110000000000001111",
        "11110000000000001111"
    ];

    class Bunker {
        constructor(x, y, pixelSize = 2, color = "#33FF33") {
            this.x = x;
            this.y = y;
            this.pixelSize = pixelSize;
            this.color = color;
            this.rows = BUNKER_TEMPLATE.length;
            this.cols = BUNKER_TEMPLATE[0].length;
            this.width = this.cols * pixelSize;
            this.height = this.rows * pixelSize;
            
            // ピクセルの状態グリッド (1: 存在, 0: 破壊)
            this.grid = [];
            for (let r = 0; r < this.rows; r++) {
                this.grid[r] = [];
                for (let c = 0; c < this.cols; c++) {
                    this.grid[r][c] = BUNKER_TEMPLATE[r][c] === '1' ? 1 : 0;
                }
            }
        }

        // 衝突判定と破壊（半径 radius ピクセルを削る）
        damage(hitX, hitY, radius = 3) {
            const centerC = Math.floor((hitX - this.x) / this.pixelSize);
            const centerR = Math.floor((hitY - this.y) / this.pixelSize);

            let hitSomething = false;
            for (let r = centerR - radius; r <= centerR + radius; r++) {
                for (let c = centerC - radius; c <= centerC + radius; c++) {
                    if (r >= 0 && r < this.rows && c >= 0 && c < this.cols) {
                        const dist = Math.sqrt((r - centerR)**2 + (c - centerC)**2);
                        if (dist <= radius + (Math.random() * 0.8)) {
                            if (this.grid[r][c] === 1) {
                                this.grid[r][c] = 0;
                                hitSomething = true;
                            }
                        }
                    }
                }
            }
            return hitSomething;
        }

        // 指定の矩形と接触しているか確認
        checkHit(rectX, rectY, rectW, rectH) {
            if (rectX + rectW < this.x || rectX > this.x + this.width ||
                rectY + rectH < this.y || rectY > this.y + this.height) {
                return false;
            }
            // 重なっているピクセルがあるか検査
            const startC = Math.max(0, Math.floor((rectX - this.x) / this.pixelSize));
            const endC = Math.min(this.cols - 1, Math.floor((rectX + rectW - this.x) / this.pixelSize));
            const startR = Math.max(0, Math.floor((rectY - this.y) / this.pixelSize));
            const endR = Math.min(this.rows - 1, Math.floor((rectY + rectH - this.y) / this.pixelSize));

            for (let r = startR; r <= endR; r++) {
                for (let c = startC; c <= endC; c++) {
                    if (this.grid[r][c] === 1) return true;
                }
            }
            return false;
        }

        // インベーダーが通過した際の侵食破壊
        corrode(rectX, rectY, rectW, rectH) {
            if (rectX + rectW < this.x || rectX > this.x + this.width ||
                rectY + rectH < this.y || rectY > this.y + this.height) {
                return;
            }
            const startC = Math.max(0, Math.floor((rectX - this.x) / this.pixelSize));
            const endC = Math.min(this.cols - 1, Math.floor((rectX + rectW - this.x) / this.pixelSize));
            const startR = Math.max(0, Math.floor((rectY - this.y) / this.pixelSize));
            const endR = Math.min(this.rows - 1, Math.floor((rectY + rectH - this.y) / this.pixelSize));

            for (let r = startR; r <= endR; r++) {
                for (let c = startC; c <= endC; c++) {
                    this.grid[r][c] = 0;
                }
            }
        }

        draw() {
            ctx.fillStyle = this.color;
            for (let r = 0; r < this.rows; r++) {
                for (let c = 0; c < this.cols; c++) {
                    if (this.grid[r][c] === 1) {
                        ctx.fillRect(this.x + c * this.pixelSize, this.y + r * this.pixelSize, this.pixelSize, this.pixelSize);
                    }
                }
            }
        }
    }

    // ─────────────────────────────────────────────
    // 背景画像管理 & スターフィールド
    // ─────────────────────────────────────────────
    const bgImages = {
        "space-bg": new Image(),
        "space-nebula": new Image()
    };
    bgImages["space-bg"].src = "assets/space-bg.jpg";
    bgImages["space-nebula"].src = "assets/space-nebula.jpg";

    // プロシージャル星空（スターフィールド）
    const stars = [];
    const STAR_COUNT = 60;
    for (let i = 0; i < STAR_COUNT; i++) {
        stars.push({
            x: Math.random() * V_WIDTH,
            y: Math.random() * V_HEIGHT,
            size: Math.random() < 0.25 ? 2 : 1,
            speed: 0.2 + Math.random() * 0.6,
            alpha: 0.3 + Math.random() * 0.7,
            twinkleSpeed: 0.02 + Math.random() * 0.04
        });
    }

    function updateStarfield() {
        for (let s of stars) {
            s.y += s.speed;
            if (s.y > V_HEIGHT) {
                s.y = 0;
                s.x = Math.random() * V_WIDTH;
            }
            s.alpha += Math.sin(Date.now() * s.twinkleSpeed) * 0.02;
            if (s.alpha < 0.2) s.alpha = 0.2;
            if (s.alpha > 1.0) s.alpha = 1.0;
        }
    }

    function drawStarfield(opacityMult = 1.0) {
        ctx.save();
        for (let s of stars) {
            ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(1, Math.max(0, s.alpha * opacityMult))})`;
            ctx.fillRect(Math.floor(s.x), Math.floor(s.y), s.size, s.size);
        }
        ctx.restore();
    }


    // ─────────────────────────────────────────────
    // ゲーム状態
    // ─────────────────────────────────────────────
    let gameState = "READY"; // "READY", "PLAYING", "PLAYER_DYING", "GAME_OVER", "CLEAR"
    let score = 0;
    let hiScore = parseInt(localStorage.getItem("invader_hiscore") || "0", 10);
    let wave = 1;
    let maxWaves = 3; // クリアに必要なウェーブ数 (3 または 5)
    let currentDifficulty = "normal"; // "easy", "normal", "hard"
    let lives = 3;
    let playerPowerLevel = 1; // 自機のショット段階 (1: 通常, 2: 2連装, 3: 3WAY)
    let animFrame = 0; // 0 or 1
    let stepTimer = 0;
    let stepInterval = 45; // インベーダー歩行間隔 (フレーム数)

    // 難易度プリセット
    const DIFFICULTY_PRESETS = {
        easy: {
            lives: 5,
            shootInterval: 70,
            bulletSpeed: 2.8,
            passThroughPlayer: true,
            fireInterval: 8,
            maxBullets: 10
        },
        normal: {
            lives: 3,
            shootInterval: 50,
            bulletSpeed: 3.5,
            passThroughPlayer: true,
            fireInterval: 10,
            maxBullets: 8
        },
        hard: {
            lives: 2,
            shootInterval: 32,
            bulletSpeed: 4.2,
            passThroughPlayer: false,
            fireInterval: 14,
            maxBullets: 6
        }
    };

    // 難易度による補正 (config.js の値を NORMAL として、そこからの増減)
    //   lives: 残機の増減 / interval: 敵の発射間隔の倍率 / speed: 敵弾速度の倍率
    const DIFFICULTY_MODS = {
        easy:   { lives: 2,  interval: 1.4,  speed: 0.8, noPassThrough: false },
        normal: { lives: 0,  interval: 1.0,  speed: 1.0, noPassThrough: false },
        hard:   { lives: -1, interval: 0.65, speed: 1.2, noPassThrough: true }
    };
    function diffMod() {
        return DIFFICULTY_MODS[currentDifficulty] || DIFFICULTY_MODS.normal;
    }

    // ホーム画面で選んだ項目は優先し、未選択の場合は config.js の game 設定を使う
    let difficultyChosen = false;
    let wavesChosen = false;
    function applyGameSettings() {
        const gCfg = (window.GameConfig && window.GameConfig.game) || {};
        if (!difficultyChosen) {
            const d = String(gCfg.difficulty || "normal");
            currentDifficulty = DIFFICULTY_MODS[d] ? d : "normal";
        }
        if (!wavesChosen) {
            maxWaves = safeNum(gCfg.maxWaves, 1, 10, 3);
        }
        syncHomeButtons();
    }

    function syncHomeButtons() {
        document.querySelectorAll("#diff-options .arcade-pill").forEach(b => {
            b.classList.toggle("active", b.getAttribute("data-diff") === currentDifficulty);
        });
        document.querySelectorAll("#wave-options .arcade-pill").forEach(b => {
            b.classList.toggle("active", parseInt(b.getAttribute("data-waves"), 10) === maxWaves);
        });
        const hs = document.getElementById("home-hiscore");
        if (hs) hs.textContent = String(hiScore).padStart(5, "0");
    }

    // プレイヤー
    let player = {
        x: V_WIDTH / 2 - 13,
        y: V_HEIGHT - 60,
        pixelSize: 2,
        width: 26,
        height: 16,
        speed: 5,
        color: "#00FF66",
        dyingTimer: 0
    };

    let playerBullets = [];
    let enemyBullets = [];
    let explosions = []; // { x, y, timer, scoreText }
    let enemies = [];
    let enemyDir = 1; // 1: 右, -1: 左
    let bunkers = [];

    // UFO
    let ufo = {
        active: false,
        x: -40,
        y: 65,
        width: 32,
        height: 14,
        speed: 2.2,
        dir: 1,
        timer: 0,
        color: "#FF0033"
    };

    // 操作キー
    const keys = {
        left: false,
        right: false,
        shoot: false
    };

    // ─────────────────────────────────────────────
    // インベーダーの初期化 (ウェーブ別フォーメーション)
    // ─────────────────────────────────────────────
    function initEnemies() {
        enemies = [];
        const cfg = window.GameConfig ? window.GameConfig.enemy : {};
        const rows = safeNum(cfg.rows, 1, 10, 5);
        const cols = safeNum(cfg.cols, 1, 16, 10);
        const colors = cfg.colors || ["#FFFF00", "#00FFFF", "#00FFFF", "#FF3399", "#FF3399"];
        const scores = cfg.scores || [30, 20, 20, 10, 10];

        // 画面幅に合わせた等間隔配置
        const maxW = V_WIDTH - 60;
        const spacingX = Math.min(36, Math.floor(maxW / Math.max(1, cols)));
        const startX = Math.max(20, Math.floor((V_WIDTH - (cols - 1) * spacingX - 24) / 2));
        const baseStartY = 85;
        const spacingY = 28;

        for (let r = 0; r < rows; r++) {
            // スプライト種類の決定: 0行目=squid, 1-2行目=crab, 3行目以降=octopus
            let type = "octopus";
            let pixelSize = 2;
            if (r === 0) {
                type = "squid";
            } else if (r === 1 || r === 2) {
                type = "crab";
            }

            const spritePattern = getSprite(type, 0);
            const dims = getSpriteDimensions(spritePattern, pixelSize);

            const rowColor = colors[r % colors.length] || "#00FFFF";
            const rowScore = scores[r % scores.length] || 10;

            for (let c = 0; c < cols; c++) {
                // ウェーブごとのフォーメーション変位
                let offsetY = 0;
                let active = true;

                if (wave === 2) {
                    // Wave 2: V字フォーメーション (中央が奥、両端が手前)
                    const centerCol = (cols - 1) / 2;
                    offsetY = (Math.abs(c - centerCol)) * 6;
                } else if (wave === 3) {
                    // Wave 3: ピラミッド型 (上段を少なく、下段を広く)
                    const centerCol = (cols - 1) / 2;
                    const allowedWidth = (r + 1) * 2;
                    if (Math.abs(c - centerCol) > allowedWidth / 2) {
                        active = false;
                    }
                } else if (wave === 4) {
                    // Wave 4: 菱形陣形
                    const centerCol = (cols - 1) / 2;
                    const centerRow = (rows - 1) / 2;
                    const dist = Math.abs(c - centerCol) + Math.abs(r - centerRow);
                    if (dist > 4) {
                        active = false;
                    }
                } else if (wave >= 5) {
                    // Wave 5: 逆V字突撃陣 (中央が突出)
                    const centerCol = (cols - 1) / 2;
                    offsetY = - (Math.abs(c - centerCol)) * 6;
                }

                if (!active) continue;

                enemies.push({
                    x: startX + c * spacingX,
                    y: baseStartY + r * spacingY + offsetY,
                    origX: startX + c * spacingX,
                    width: dims.width,
                    height: dims.height,
                    type: type,
                    pixelSize: pixelSize,
                    color: rowColor,
                    score: rowScore,
                    alive: true,
                    row: r,
                    col: c
                });
            }
        }

        // 敵が存在しない場合の安全対策 (フォールバック)
        if (enemies.length === 0) {
            wave = 1;
            initEnemies();
            return;
        }

        enemyDir = 1;
        stepInterval = Math.max(10, 52 - wave * 5);
        stepTimer = 0;
    }

    // ─────────────────────────────────────────────
    // 防壁の初期化
    // ─────────────────────────────────────────────
    function initBunkers() {
        bunkers = [];
        const cfg = window.GameConfig ? window.GameConfig.bunker : {};
        if (cfg.enabled === false) return;

        const count = safeNum(cfg.count, 0, 8, 4);
        if (count <= 0) return;

        const color = cfg.color || "#33FF33";
        const bunkerWidth = 40;
        const spacing = (V_WIDTH - (count * bunkerWidth)) / (count + 1);

        for (let i = 0; i < count; i++) {
            const bx = spacing + i * (bunkerWidth + spacing);
            const by = V_HEIGHT - 130;
            bunkers.push(new Bunker(bx, by, 2, color));
        }
    }

    // ─────────────────────────────────────────────
    // ゲームの開始 & リセット & 一時停止 (PAUSE)
    // ─────────────────────────────────────────────
    let pauseMode = "menu"; // "menu" (2択画面) | "edit" (HUD控えめ表示)

    function pauseGame(mode = "menu") {
        if (gameState !== "PLAYING" && gameState !== "PAUSED") return;
        gameState = "PAUSED";
        pauseMode = mode;

        const pauseOverlay = document.getElementById("pause-overlay");
        const pauseMenu = document.getElementById("pause-menu-box");
        const pauseHud = document.getElementById("pause-hud-box");
        const quickPauseBtn = document.getElementById("btn-quick-pause");

        if (pauseOverlay) {
            pauseOverlay.style.display = "flex";
            if (mode === "edit") {
                pauseOverlay.classList.add("edit-mode");
            } else {
                pauseOverlay.classList.remove("edit-mode");
            }
        }
        if (quickPauseBtn) quickPauseBtn.style.display = "none";

        if (mode === "edit") {
            if (pauseMenu) pauseMenu.style.display = "none";
            if (pauseHud) pauseHud.style.display = "flex";
        } else {
            if (pauseMenu) pauseMenu.style.display = "flex";
            if (pauseHud) pauseHud.style.display = "none";
        }
        draw();
    }

    function resumeGame() {
        if (gameState !== "PAUSED") return;
        gameState = "PLAYING";

        const pauseOverlay = document.getElementById("pause-overlay");
        const quickPauseBtn = document.getElementById("btn-quick-pause");
        if (pauseOverlay) {
            pauseOverlay.style.display = "none";
            pauseOverlay.classList.remove("edit-mode");
        }
        if (quickPauseBtn) quickPauseBtn.style.display = "block";

        canvas.focus();
    }

    function quitToHome() {
        const pauseOverlay = document.getElementById("pause-overlay");
        const quickPauseBtn = document.getElementById("btn-quick-pause");
        if (pauseOverlay) {
            pauseOverlay.style.display = "none";
            pauseOverlay.classList.remove("edit-mode");
        }
        if (quickPauseBtn) quickPauseBtn.style.display = "none";
        resetGame(true, false);
    }

    function startGame() {
        initAudio();
        gameState = "PLAYING";
        const overlay = document.getElementById("start-overlay");
        const pauseOverlay = document.getElementById("pause-overlay");
        const quickPauseBtn = document.getElementById("btn-quick-pause");

        if (overlay) overlay.classList.add("hidden");
        if (pauseOverlay) pauseOverlay.style.display = "none";
        if (quickPauseBtn) quickPauseBtn.style.display = "block";
        canvas.focus();
    }

    function resetGame(fullReset = true, autoStart = false) {
        const pCfg = window.GameConfig ? window.GameConfig.player : {};
        const pSprite = getSprite("player");
        const pDims = getSpriteDimensions(pSprite, player.pixelSize);
        player.width = pDims.width;
        player.height = pDims.height;
        player.speed = safeNum(pCfg.speed, 0, 50, 5);
        player.color = pCfg.color || "#00FF66";
        player.x = V_WIDTH / 2 - player.width / 2;
        player.y = V_HEIGHT - 60;
        player.dyingTimer = 0;

        const uCfg = window.GameConfig ? window.GameConfig.ufo : {};
        if (uCfg) {
            ufo.speed = safeNum(uCfg.speed, 0.5, 30, 2.2);
            ufo.color = uCfg.color || "#FF0033";
        }

        playerBullets = [];
        enemyBullets = [];
        explosions = [];
        ufo.active = false;
        ufo.timer = 0;
        Sound.stopUFO();

        if (fullReset) {
            applyGameSettings();
            lives = Math.max(1, safeNum(pCfg.lives, 1, 99999, 3) + diffMod().lives);
            score = 0;
            wave = 1;
            playerPowerLevel = 1;
            initBunkers();
        }

        initEnemies();

        const overlay = document.getElementById("start-overlay");
        const pauseOverlay = document.getElementById("pause-overlay");
        const quickPauseBtn = document.getElementById("btn-quick-pause");

        if (pauseOverlay) pauseOverlay.style.display = "none";

        if (autoStart) {
            gameState = "PLAYING";
            if (overlay) overlay.classList.add("hidden");
            if (quickPauseBtn) quickPauseBtn.style.display = "block";
        } else {
            gameState = "READY";
            if (overlay) overlay.classList.remove("hidden");
            if (quickPauseBtn) quickPauseBtn.style.display = "none";
        }
    }

    // ─────────────────────────────────────────────
    // ⌨️ キーボード入力処理 & メッセージ連携
    // ─────────────────────────────────────────────
    let shootCooldown = 0;

    function handleKeyDown(code) {
        initAudio();

        if (code === "Escape") {
            if (gameState === "PLAYING") {
                pauseGame("menu");
                return;
            } else if (gameState === "PAUSED") {
                resumeGame();
                return;
            }
        }

        if (code === "ArrowLeft" || code === "KeyA") {
            keys.left = true;
        }
        if (code === "ArrowRight" || code === "KeyD") {
            keys.right = true;
        }
        if (code === "Space" || code === "KeyZ") {
            keys.shoot = true;
            if (document.activeElement && document.activeElement !== canvas && document.activeElement.blur) {
                document.activeElement.blur();
            }

            if (gameState === "PAUSED") {
                if (pauseMode === "edit") {
                    resumeGame();
                } else {
                    pauseGame("edit");
                }
                return;
            }

            if (gameState === "READY") {
                startGame();
            } else if (gameState === "GAME_OVER" || gameState === "CLEAR") {
                resetGame(true, false);
            } else if (shootCooldown <= 0) {
                firePlayerBullet();
                const pCfg = window.GameConfig ? window.GameConfig.player : {};
                const preset = DIFFICULTY_PRESETS[currentDifficulty] || DIFFICULTY_PRESETS.normal;
                shootCooldown = safeNum(pCfg.fireInterval, 2, 60, preset.fireInterval);
            }
        }
    }

    function handleKeyUp(code) {
        if (code === "ArrowLeft" || code === "KeyA") keys.left = false;
        if (code === "ArrowRight" || code === "KeyD") keys.right = false;
        if (code === "Space" || code === "KeyZ") {
            keys.shoot = false;
            shootCooldown = 0;
        }
    }

    window.addEventListener("keydown", (e) => {
        if (["Space", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Escape"].includes(e.code)) {
            e.preventDefault();
        }
        handleKeyDown(e.code);
    });

    window.addEventListener("keyup", (e) => {
        if (["Space", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Escape"].includes(e.code)) {
            e.preventDefault();
        }
        handleKeyUp(e.code);
    });

    // 親ウィンドウ (IDE) からのキー入力 & 設定ブリッジ
    window.addEventListener("message", (e) => {
        if (!e.data) return;
        if (e.data.type === 'KEY_EVENT') {
            if (e.data.action === 'down') handleKeyDown(e.data.code);
            if (e.data.action === 'up') handleKeyUp(e.data.code);
        } else if (e.data.type === 'SPRITE_PREVIEW_UPDATE') {
            if (typeof window.updateLiveSpritePreview === 'function') {
                const k = e.data.key || e.data.spriteKey;
                const p = e.data.pattern || e.data.spritePattern;
                window.updateLiveSpritePreview(k, p);
            }
        } else if (e.data.type === 'SET_SOUND') {
            initAudio();
            Sound.enabled = !!e.data.enabled;
            if (window.GameConfig && window.GameConfig.display) {
                window.GameConfig.display.sound = Sound.enabled;
            }
        } else if (e.data.type === 'SET_CANVAS_SCALE') {
            const sc = Number(e.data.scale);
            if (!isNaN(sc) && sc > 0) {
                const baseWidth = 440;
                canvas.style.width = Math.round(baseWidth * sc) + 'px';
                canvas.style.height = Math.round(baseWidth * sc * (560 / 480)) + 'px';
            }
        }
    });

    canvas.addEventListener("click", () => {
        canvas.focus();
        initAudio();
        if (gameState === "READY") {
            startGame();
        } else if (gameState === "GAME_OVER" || gameState === "CLEAR") {
            resetGame(true, false);
        }
    });

    // ホーム画面 (本格アーケード演出 & 難易度選択) の初期化
    let homeAnimFrame = 0;
    let homeAnimTimer = null;

    function renderHomePreviewSprites() {
        function drawToCanvas(canvasId, spriteKey, color, pixelSize = 2, frame = 0) {
            const cvs = document.getElementById(canvasId);
            if (!cvs) return;
            const cCtx = cvs.getContext("2d");
            cCtx.clearRect(0, 0, cvs.width, cvs.height);
            const pattern = getSprite(spriteKey, frame);
            if (!pattern || pattern.length === 0) return;
            
            const rows = pattern.length;
            const cols = pattern[0].length;
            if (cols === 0 || rows === 0) return;

            // キャンバス枠に美しく収まるようにスケール自動計算
            const fitSize = Math.max(1, Math.min(pixelSize, Math.floor(cvs.width / cols), Math.floor(cvs.height / rows)));
            const startX = Math.floor((cvs.width - cols * fitSize) / 2);
            const startY = Math.floor((cvs.height - rows * fitSize) / 2);

            cCtx.fillStyle = color;
            for (let r = 0; r < rows; r++) {
                const row = pattern[r];
                if (!row) continue;
                for (let c = 0; c < row.length; c++) {
                    if (row[c] === '1') {
                        cCtx.fillRect(startX + c * fitSize, startY + r * fitSize, fitSize, fitSize);
                    }
                }
            }
        }

        function updateSprites() {
            homeAnimFrame = 1 - homeAnimFrame;
            const cfg = window.GameConfig || {};
            const eColors = (cfg.enemy && cfg.enemy.colors) || [];
            const ufoColor = (cfg.ufo && cfg.ufo.color) || "#FF3344";
            const squidColor = eColors[0] || "#FFFF00";
            const crabColor = eColors[1] || "#00FFFF";
            const octopusColor = eColors[3] || eColors[eColors.length - 1] || "#FF3399";
            const playerColor = (cfg.player && cfg.player.color) || "#00FF66";

            drawToCanvas("preview-ufo", "ufo", ufoColor, 2, 0);
            drawToCanvas("preview-squid", "squid", squidColor, 2, homeAnimFrame);
            drawToCanvas("preview-crab", "crab", crabColor, 2, homeAnimFrame);
            drawToCanvas("preview-octopus", "octopus", octopusColor, 2, homeAnimFrame);
            drawToCanvas("preview-player", "player", playerColor, 2, 0);
        }

        updateSprites();
        if (!homeAnimTimer) {
            homeAnimTimer = setInterval(updateSprites, 480);
        }
    }

    function setupPauseUI() {
        const quickPauseBtn = document.getElementById("btn-quick-pause");
        const btnPauseEdit = document.getElementById("btn-pause-edit");
        const btnPauseQuit = document.getElementById("btn-pause-quit");
        const btnHudResume = document.getElementById("btn-hud-resume");
        const btnHudQuit = document.getElementById("btn-hud-quit");

        if (quickPauseBtn) {
            quickPauseBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                pauseGame("menu");
            });
        }
        if (btnPauseEdit) {
            btnPauseEdit.addEventListener("click", (e) => {
                e.stopPropagation();
                pauseGame("edit");
            });
        }
        if (btnPauseQuit) {
            btnPauseQuit.addEventListener("click", (e) => {
                e.stopPropagation();
                quitToHome();
            });
        }
        if (btnHudResume) {
            btnHudResume.addEventListener("click", (e) => {
                e.stopPropagation();
                resumeGame();
            });
        }
        if (btnHudQuit) {
            btnHudQuit.addEventListener("click", (e) => {
                e.stopPropagation();
                quitToHome();
            });
        }
    }

    function setupHomeUI() {
        const btnStart = document.getElementById("btn-game-start");
        if (btnStart) {
            btnStart.addEventListener("click", (e) => {
                e.stopPropagation();
                startGame();
            });
        }

        // 難易度ボタンの選択
        const diffButtons = document.querySelectorAll("#diff-options .arcade-pill");
        diffButtons.forEach(btn => {
            btn.addEventListener("click", (e) => {
                e.stopPropagation();
                difficultyChosen = true;
                currentDifficulty = btn.getAttribute("data-diff") || "normal";
                resetGame(true, false);
                btn.blur();
            });
        });

        // クリア条件 (ウェーブ数) ボタンの選択
        const waveButtons = document.querySelectorAll("#wave-options .arcade-pill");
        waveButtons.forEach(btn => {
            btn.addEventListener("click", (e) => {
                e.stopPropagation();
                wavesChosen = true;
                maxWaves = parseInt(btn.getAttribute("data-waves") || "3", 10);
                syncHomeButtons();
                btn.blur();
            });
        });

        setupPauseUI();
        renderHomePreviewSprites();
    }

    // 画面下部のオンスクリーンボタン
    function setupTouchControls() {
        const btnLeft = document.getElementById("btn-left");
        const btnRight = document.getElementById("btn-right");
        const btnFire = document.getElementById("btn-fire");
        const btnSound = document.getElementById("btn-sound");

        function bindTouch(elem, onDown, onUp) {
            if (!elem) return;
            const start = (e) => {
                e.preventDefault();
                initAudio();
                onDown();
            };
            const end = (e) => {
                e.preventDefault();
                onUp();
            };
            elem.addEventListener("touchstart", start, { passive: false });
            elem.addEventListener("touchend", end, { passive: false });
            elem.addEventListener("mousedown", start);
            elem.addEventListener("mouseup", end);
            elem.addEventListener("mouseleave", onUp);
        }

        bindTouch(btnLeft, () => keys.left = true, () => keys.left = false);
        bindTouch(btnRight, () => keys.right = true, () => keys.right = false);
        bindTouch(btnFire, () => {
            keys.shoot = true;
            if (gameState === "READY") {
                startGame();
            } else if (gameState === "GAME_OVER" || gameState === "CLEAR") {
                resetGame(true, false);
            } else {
                firePlayerBullet();
            }
        }, () => keys.shoot = false);

        if (btnSound) {
            btnSound.addEventListener("click", () => {
                initAudio();
                Sound.enabled = !Sound.enabled;
                btnSound.textContent = Sound.enabled ? "ON" : "OFF";
            });
        }
    }

    // ─────────────────────────────────────────────
    // 弾の発射 (連射 & パワーアップショット)
    // ─────────────────────────────────────────────
    function firePlayerBullet() {
        if (gameState !== "PLAYING") return;
        const bCfg = window.GameConfig ? window.GameConfig.bullet : {};
        const pCfg = window.GameConfig ? window.GameConfig.player : {};
        const preset = DIFFICULTY_PRESETS[currentDifficulty] || DIFFICULTY_PRESETS.normal;
        const maxBullets = safeNum(pCfg.maxBullets, 1, 100, preset.maxBullets);

        if (playerBullets.length >= maxBullets) return;

        const bw = safeNum(bCfg.width, 1, 100, 3);
        const bh = safeNum(bCfg.height, 2, 100, 12);
        const spd = safeNum(bCfg.speed, -100, -1, -8);
        const col = bCfg.color || "#FFFF00";

        if (playerPowerLevel === 1) {
            // Level 1: 通常単発
            playerBullets.push({
                x: player.x + player.width / 2 - bw / 2,
                y: player.y - bh,
                vx: 0,
                width: bw,
                height: bh,
                speed: spd,
                color: col
            });
        } else if (playerPowerLevel === 2) {
            // Level 2: 2連装平行ショット
            playerBullets.push({
                x: player.x + 3,
                y: player.y - bh,
                vx: 0,
                width: bw,
                height: bh,
                speed: spd,
                color: col
            });
            playerBullets.push({
                x: player.x + player.width - 3 - bw,
                y: player.y - bh,
                vx: 0,
                width: bw,
                height: bh,
                speed: spd,
                color: col
            });
        } else {
            // Level 3+: 3WAYショット
            playerBullets.push({
                x: player.x + player.width / 2 - bw / 2,
                y: player.y - bh,
                vx: 0,
                width: bw,
                height: bh,
                speed: spd,
                color: col
            });
            playerBullets.push({
                x: player.x + 2,
                y: player.y - bh,
                vx: -1.2,
                width: bw,
                height: bh,
                speed: spd,
                color: col
            });
            playerBullets.push({
                x: player.x + player.width - 2 - bw,
                y: player.y - bh,
                vx: 1.2,
                width: bw,
                height: bh,
                speed: spd,
                color: col
            });
        }

        Sound.playShoot();
    }

    function fireEnemyBullet(enemy) {
        const eCfg = window.GameConfig ? window.GameConfig.enemy : {};
        const preset = DIFFICULTY_PRESETS[currentDifficulty] || DIFFICULTY_PRESETS.normal;
        const spd = safeNum(eCfg.bulletSpeed, 1, 10, 3.5) * diffMod().speed;

        // Wave 2以降、一部の弾をプレイヤー狙いのエイム弾にする
        let vx = 0;
        if (wave >= 2 && Math.random() < 0.35) {
            const dx = (player.x + player.width / 2) - (enemy.x + enemy.width / 2);
            vx = Math.max(-1.4, Math.min(1.4, dx / 70));
        }

        enemyBullets.push({
            x: enemy.x + enemy.width / 2 - 1.5,
            y: enemy.y + enemy.height,
            vx: vx,
            width: 3,
            height: 10,
            speed: spd,
            wiggleTimer: 0
        });
    }

    // ─────────────────────────────────────────────
    // UFO ロジック
    // ─────────────────────────────────────────────
    function updateUFO() {
        const uCfg = window.GameConfig ? window.GameConfig.ufo : {};
        if (uCfg.enabled === false) return;

        const interval = safeNum(uCfg.interval, 5, 60, 18) * 60; // フレーム換算
        ufo.color = uCfg.color || "#FF0033";
        ufo.speed = safeNum(uCfg.speed, 1, 10, 2.2);

        if (!ufo.active) {
            ufo.timer++;
            if (ufo.timer >= interval) {
                ufo.active = true;
                ufo.timer = 0;
                ufo.dir = Math.random() < 0.5 ? 1 : -1;
                ufo.x = ufo.dir === 1 ? -40 : V_WIDTH + 10;
                Sound.startUFO();
            }
        } else {
            ufo.x += ufo.speed * ufo.dir;
            if ((ufo.dir === 1 && ufo.x > V_WIDTH + 40) || (ufo.dir === -1 && ufo.x < -60)) {
                ufo.active = false;
                Sound.stopUFO();
            }
        }
    }

    // ─────────────────────────────────────────────
    // メイン更新 (Update Loop)
    // ─────────────────────────────────────────────
    function update() {
        const eCfg = window.GameConfig ? window.GameConfig.enemy : {};
        const pCfg = window.GameConfig ? window.GameConfig.player : {};
        const preset = DIFFICULTY_PRESETS[currentDifficulty] || DIFFICULTY_PRESETS.normal;

        if (window.GameConfig && window.GameConfig.display && typeof window.GameConfig.display.sound === 'boolean') {
            Sound.enabled = window.GameConfig.display.sound;
        }

        // プレイヤー被弾中の演出待機
        if (gameState === "PLAYER_DYING") {
            player.dyingTimer--;
            if (player.dyingTimer <= 0) {
                if (lives > 0) {
                    gameState = "PLAYING";
                    player.x = V_WIDTH / 2 - player.width / 2;
                } else {
                    gameState = "GAME_OVER";
                }
            }
            return;
        }

        if (gameState !== "PLAYING") return;

        // プレイヤー移動
        player.speed = safeNum(pCfg.speed, 1, 20, 5);
        player.color = pCfg.color || "#00FF66";
        if (keys.left) player.x -= player.speed;
        if (keys.right) player.x += player.speed;
        player.x = Math.max(10, Math.min(V_WIDTH - player.width - 10, player.x));

        // プレイヤー射撃 (押しっぱなし連射)
        if (keys.shoot) {
            shootCooldown--;
            if (shootCooldown <= 0) {
                firePlayerBullet();
                shootCooldown = safeNum(pCfg.fireInterval, 2, 60, preset.fireInterval);
            }
        }

        // プレイヤーの弾移動
        for (let i = playerBullets.length - 1; i >= 0; i--) {
            const b = playerBullets[i];
            b.x += (b.vx || 0);
            b.y += b.speed;
            if (b.y < 35 || b.x < 0 || b.x > V_WIDTH) {
                playerBullets.splice(i, 1);
            }
        }

        // 敵の弾移動
        for (let i = enemyBullets.length - 1; i >= 0; i--) {
            const eb = enemyBullets[i];
            eb.y += eb.speed;
            eb.x += (eb.vx || 0);
            eb.wiggleTimer++;
            eb.x += Math.sin(eb.wiggleTimer * 0.4) * 0.6;
            if (eb.y > V_HEIGHT - 30) {
                enemyBullets.splice(i, 1);
            }
        }

        // 爆発エフェクトのタイマー更新
        for (let i = explosions.length - 1; i >= 0; i--) {
            explosions[i].timer--;
            if (explosions[i].timer <= 0) {
                explosions.splice(i, 1);
            }
        }

        // UFO 更新
        updateUFO();

        // ── インベーダーの行進 ──
        const aliveEnemies = enemies.filter(e => e.alive);
        if (aliveEnemies.length === 0) {
            // 全滅！ウェーブクリア判定
            wave++;
            Sound.stopUFO();

            if (wave > maxWaves) {
                // 全ウェーブ走破！ゲームクリア
                gameState = "CLEAR";
                Sound.playUFOHit();
                return;
            }

            // 次のウェーブへ
            playerPowerLevel = Math.min(3, wave);

            // 防壁の毎ウェーブ再生
            const bCfg = window.GameConfig ? window.GameConfig.bunker : {};
            const regenerate = (bCfg.regenerateEachWave !== false);
            if (regenerate) {
                initBunkers();
            }

            playerBullets = [];
            enemyBullets = [];
            initEnemies();
            return;
        }

        // 残り匹数に応じた行進テンポの加速
        const baseSpeed = safeNum(eCfg.speed, 0.2, 5, 1.0);
        const aliveRatio = aliveEnemies.length / enemies.length;
        stepInterval = Math.max(4, Math.floor((40 * aliveRatio) / baseSpeed));

        stepTimer++;
        if (stepTimer >= stepInterval) {
            stepTimer = 0;
            animFrame = 1 - animFrame;
            Sound.playWalk();

            let hitEdge = false;
            const stepDx = 6 * enemyDir;
            for (let e of aliveEnemies) {
                const nextX = e.x + stepDx;
                if (nextX < 15 || nextX + e.width > V_WIDTH - 15) {
                    hitEdge = true;
                    break;
                }
            }

            const dropAmount = safeNum(eCfg.dropAmount, 2, 40, 14);

            if (hitEdge) {
                enemyDir *= -1;
                for (let e of aliveEnemies) {
                    e.y += dropAmount;
                }
            } else {
                for (let e of aliveEnemies) {
                    e.x += stepDx;
                }
            }

            // 防壁の侵食チェック
            for (let e of aliveEnemies) {
                for (let bunker of bunkers) {
                    bunker.corrode(e.x, e.y, e.width, e.height);
                }
            }

            // 最前線到達チェック
            const invasionLine = player.y - 10;
            for (let e of aliveEnemies) {
                if (e.y + e.height >= invasionLine) {
                    gameState = "GAME_OVER";
                    Sound.playPlayerHit();
                    return;
                }
            }
        }

        // ── 敵の射撃 ──
        const shootInterval = Math.max(10, safeNum(eCfg.shootInterval, 10, 200, 50) * diffMod().interval);
        if (Math.random() < (1.0 / shootInterval)) {
            const bottomEnemies = [];
            const colMap = {};
            for (let e of aliveEnemies) {
                if (!colMap[e.col] || colMap[e.col].row < e.row) {
                    colMap[e.col] = e;
                }
            }
            for (let col in colMap) {
                bottomEnemies.push(colMap[col]);
            }
            if (bottomEnemies.length > 0 && enemyBullets.length < 5) {
                const shooter = bottomEnemies[Math.floor(Math.random() * bottomEnemies.length)];
                fireEnemyBullet(shooter);
            }
        }

        // ── 当たり判定: プレイヤー弾 vs 敵 ──
        for (let bi = playerBullets.length - 1; bi >= 0; bi--) {
            const pb = playerBullets[bi];
            let bulletRemoved = false;

            // UFO との判定
            if (ufo.active) {
                if (pb.x < ufo.x + ufo.width && pb.x + pb.width > ufo.x &&
                    pb.y < ufo.y + ufo.height && pb.y + pb.height > ufo.y) {
                    ufo.active = false;
                    playerBullets.splice(bi, 1);
                    bulletRemoved = true;
                    const uCfg = window.GameConfig ? window.GameConfig.ufo : {};
                    const uScore = safeNum(uCfg.bonusScore, 50, 1000, 300);
                    score += uScore;
                    if (score > hiScore) {
                        hiScore = score;
                        localStorage.setItem("invader_hiscore", hiScore);
                    }
                    Sound.playUFOHit();
                    explosions.push({
                        x: ufo.x,
                        y: ufo.y,
                        timer: 25,
                        scoreText: uScore
                    });
                    continue;
                }
            }

            // インベーダーとの判定
            for (let e of aliveEnemies) {
                if (pb.x < e.x + e.width && pb.x + pb.width > e.x &&
                    pb.y < e.y + e.height && pb.y + pb.height > e.y) {
                    e.alive = false;
                    playerBullets.splice(bi, 1);
                    bulletRemoved = true;
                    score += e.score;
                    if (score > hiScore) {
                        hiScore = score;
                        localStorage.setItem("invader_hiscore", hiScore);
                    }
                    Sound.playInvaderHit();
                    explosions.push({
                        x: e.x,
                        y: e.y,
                        timer: 12,
                        color: e.color
                    });
                    break;
                }
            }

            if (bulletRemoved) continue;

            // 防壁との判定 (自弾が貫通するかどうか)
            const bCfg = window.GameConfig ? window.GameConfig.bunker : {};
            const passThrough = (bCfg.passThroughPlayer !== false) && !diffMod().noPassThrough;

            if (!passThrough) {
                for (let bunker of bunkers) {
                    if (bunker.checkHit(pb.x, pb.y, pb.width, pb.height)) {
                        bunker.damage(pb.x + pb.width / 2, pb.y, 4);
                        playerBullets.splice(bi, 1);
                        break;
                    }
                }
            }
        }

        // ── 当たり判定: 敵弾 vs 防壁 ──
        for (let ebi = enemyBullets.length - 1; ebi >= 0; ebi--) {
            const eb = enemyBullets[ebi];
            for (let bunker of bunkers) {
                if (bunker.checkHit(eb.x, eb.y, eb.width, eb.height)) {
                    bunker.damage(eb.x + eb.width / 2, eb.y + eb.height, 4);
                    enemyBullets.splice(ebi, 1);
                    break;
                }
            }
        }

        // ── 当たり判定: 敵弾 vs プレイヤー弾 (相殺) ──
        for (let bi = playerBullets.length - 1; bi >= 0; bi--) {
            const pb = playerBullets[bi];
            for (let ebi = enemyBullets.length - 1; ebi >= 0; ebi--) {
                const eb = enemyBullets[ebi];
                if (Math.abs(pb.x - eb.x) < 5 && Math.abs(pb.y - eb.y) < 8) {
                    playerBullets.splice(bi, 1);
                    enemyBullets.splice(ebi, 1);
                    break;
                }
            }
        }

        // ── 当たり判定: 敵弾 vs プレイヤー ──
        for (let ebi = enemyBullets.length - 1; ebi >= 0; ebi--) {
            const eb = enemyBullets[ebi];
            if (eb.x < player.x + player.width && eb.x + eb.width > player.x &&
                eb.y < player.y + player.height && eb.y + eb.height > player.y) {
                enemyBullets.splice(ebi, 1);
                lives--;
                Sound.playPlayerHit();
                gameState = "PLAYER_DYING";
                player.dyingTimer = 60; // 1秒間やられ演出
                break;
            }
        }
    }

    // ─────────────────────────────────────────────
    // 描画ループ (Draw Loop)
    // ─────────────────────────────────────────────
    function draw() {
        ctx.clearRect(0, 0, V_WIDTH, V_HEIGHT);

        // 1. 宇宙背景の描画
        const dCfg = window.GameConfig ? window.GameConfig.display : {};
        const bgChoice = (dCfg && dCfg.background) || "space-bg";

        let bgDrawn = false;
        if (bgChoice !== "black" && bgImages[bgChoice]) {
            const img = bgImages[bgChoice];
            if (img.complete && img.naturalWidth > 0) {
                try {
                    ctx.drawImage(img, 0, 0, V_WIDTH, V_HEIGHT);
                    // 視認性を保つための半透明オーバーレイ
                    ctx.fillStyle = "rgba(5, 5, 12, 0.65)";
                    ctx.fillRect(0, 0, V_WIDTH, V_HEIGHT);
                    bgDrawn = true;
                } catch (e) {
                    bgDrawn = false;
                }
            }
        }

        // 画像が無い、またはエラーの時は美しい星空（スターフィールド）を描画
        if (!bgDrawn) {
            ctx.fillStyle = "#000000";
            ctx.fillRect(0, 0, V_WIDTH, V_HEIGHT);
            drawStarfield();
        } else {
            // 画像がある場合も星空を控えめにブレンド
            drawStarfield(0.35);
        }



        // 2. ヘッダースコア (クラシックなアーケード表示)
        ctx.font = "14px 'Courier New', monospace, monospace";
        ctx.textBaseline = "top";
        
        ctx.fillStyle = "#00FFFF";
        ctx.fillText("SCORE<1>", 30, 10);
        ctx.fillStyle = "#FFFFFF";
        ctx.fillText("HI-SCORE", 190, 10);
        ctx.fillStyle = "#00FF66";
        ctx.fillText("WAVE", 370, 10);

        ctx.fillStyle = "#FFFFFF";
        ctx.fillText(String(score).padStart(5, '0'), 40, 26);
        ctx.fillStyle = "#00FFFF";
        ctx.fillText(String(hiScore).padStart(5, '0'), 200, 26);
        ctx.fillStyle = "#FFFF00";
        ctx.fillText(String(wave).padStart(2, '0'), 385, 26);

        // 3. UFO 描画
        if (ufo.active) {
            drawPixelPattern(getSprite("ufo"), ufo.x, ufo.y, 2, ufo.color);
        }

        // 4. インベーダー描画
        for (let e of enemies) {
            if (!e.alive) continue;
            const pattern = getSprite(e.type, animFrame);
            if (pattern) {
                drawPixelPattern(pattern, e.x, e.y, e.pixelSize, e.color);
            }
        }

        // 5. 防壁（バンカー）描画
        for (let bunker of bunkers) {
            bunker.draw();
        }

        // 6. プレイヤーの弾描画
        for (let b of playerBullets) {
            ctx.fillStyle = b.color;
            ctx.fillRect(b.x, b.y, b.width, b.height);
        }

        // 7. 敵の弾描画 (ジグザグ・雷型)
        for (let eb of enemyBullets) {
            ctx.fillStyle = "#FFFFFF";
            ctx.fillRect(eb.x, eb.y, eb.width, 3);
            ctx.fillRect(eb.x + 2, eb.y + 3, eb.width, 3);
            ctx.fillRect(eb.x - 2, eb.y + 6, eb.width, 3);
            ctx.fillRect(eb.x, eb.y + 9, eb.width, 3);
        }

        // 8. 爆発エフェクト
        for (let exp of explosions) {
            if (exp.scoreText) {
                ctx.fillStyle = "#FF0033";
                ctx.font = "bold 16px 'Courier New', monospace";
                ctx.fillText(exp.scoreText, exp.x, exp.y);
            } else {
                drawPixelPattern(getSprite("explosion"), exp.x, exp.y, 2, exp.color || "#FFFFFF");
            }
        }

        // 9. プレイヤー描画
        if (gameState === "PLAYER_DYING") {
            const blowFrame = Math.floor(player.dyingTimer / 8) % 2;
            drawPixelPattern(SPRITES.playerBlow[blowFrame], player.x, player.y, player.pixelSize, "#FF3333");
        } else if (gameState !== "GAME_OVER") {
            drawPixelPattern(getSprite("player"), player.x, player.y, player.pixelSize, player.color);
        }

        // 10. 最下部の境界線とステータス（残機数・クレジット表示）
        const groundY = V_HEIGHT - 32;
        ctx.fillStyle = "#FF0033";
        ctx.fillRect(0, groundY, V_WIDTH, 2);

        // 残機表示 (残機が多い場合はアイコン×数字、少ない場合はアイコン並べ)
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "14px 'Courier New', monospace";
        const playerPattern = getSprite("player");
        if (lives <= 5) {
            ctx.fillText(lives, 25, groundY + 8);
            for (let i = 0; i < Math.max(0, lives - 1); i++) {
                drawPixelPattern(playerPattern, 45 + i * 28, groundY + 6, 1.5, player.color);
            }
        } else {
            drawPixelPattern(playerPattern, 25, groundY + 6, 1.5, player.color);
            ctx.fillText(`× ${lives}`, 55, groundY + 8);
        }

        // 右下のクレジット表示
        ctx.fillStyle = "#FF00FF";
        ctx.fillText("CREDIT 00", V_WIDTH - 110, groundY + 8);

        // 11. ゲームオーバー・クリア画面
        if (gameState === "GAME_OVER") {
            ctx.fillStyle = "rgba(10, 14, 20, 0.88)";
            ctx.fillRect(0, 160, V_WIDTH, 220);

            ctx.fillStyle = "#FF3344";
            ctx.font = "bold 30px 'Courier New', monospace";
            ctx.textAlign = "center";
            ctx.fillText("GAME OVER", V_WIDTH / 2, 210);

            ctx.fillStyle = "#FFFF00";
            ctx.font = "15px 'Courier New', monospace";
            ctx.fillText("FINAL SCORE: " + score, V_WIDTH / 2, 260);

            ctx.fillStyle = "#00FFFF";
            ctx.font = "13px 'Courier New', monospace";
            ctx.fillText("PRESS [SPACE] TO RETURN TO TITLE", V_WIDTH / 2, 310);
            ctx.textAlign = "left";
        } else if (gameState === "CLEAR") {
            ctx.fillStyle = "rgba(10, 14, 20, 0.90)";
            ctx.fillRect(0, 140, V_WIDTH, 250);

            ctx.fillStyle = "#00FF66";
            ctx.font = "bold 30px 'Courier New', monospace";
            ctx.textAlign = "center";
            ctx.fillText("GAME CLEAR", V_WIDTH / 2, 190);

            ctx.fillStyle = "#FFFF00";
            ctx.font = "14px 'Courier New', monospace";
            ctx.fillText("ALL " + maxWaves + " WAVES COMPLETED", V_WIDTH / 2, 225);

            ctx.fillStyle = "#FFFFFF";
            ctx.font = "15px 'Courier New', monospace";
            ctx.fillText("FINAL SCORE: " + score, V_WIDTH / 2, 265);
            ctx.fillText("REMAINING LIVES: " + lives, V_WIDTH / 2, 295);

            ctx.fillStyle = "#00FFFF";
            ctx.font = "13px 'Courier New', monospace";
            ctx.fillText("PRESS [SPACE] TO RETURN TO TITLE", V_WIDTH / 2, 345);
            ctx.textAlign = "left";
        }
    }

    // ─────────────────────────────────────────────
    // メインループ
    // ─────────────────────────────────────────────
    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    // 起動
    function start() {
        if (!ensureCanvas()) {
            setTimeout(start, 50);
            return;
        }
        setupHomeUI();
        setupTouchControls();
        resetGame(true);
        requestAnimationFrame(loop);
    }

    if (document.readyState === 'loading') {
        window.addEventListener("DOMContentLoaded", start);
    } else {
        start();
    }

    // ポーズ中・実行中のゲームオブジェクトに設定変更（色・スプライト・スピード等）を即座に反映
    function applyConfigToActiveGame() {
        const cfg = window.GameConfig || {};
        const pCfg = cfg.player || {};
        const eCfg = cfg.enemy || {};
        const uCfg = cfg.ufo || {};

        // プレイヤーの更新
        const pSprite = getSprite("player");
        const pDims = getSpriteDimensions(pSprite, player.pixelSize);
        player.width = pDims.width;
        player.height = pDims.height;
        player.color = pCfg.color || "#00FF66";
        player.speed = safeNum(pCfg.speed, 0, 50, player.speed);

        // 敵の更新（色、サイズ）
        const colors = eCfg.colors || [];
        for (let enemy of enemies) {
            if (enemy.row === 0) enemy.color = colors[0] || "#FFFF00";
            else if (enemy.row === 1 || enemy.row === 2) enemy.color = colors[1] || "#00FFFF";
            else enemy.color = colors[3] || colors[colors.length - 1] || "#FF3399";

            const sprite = getSprite(enemy.type, enemy.animFrame);
            const dims = getSpriteDimensions(sprite, enemy.pixelSize);
            enemy.width = dims.width;
            enemy.height = dims.height;
        }

        // UFOの更新
        if (uCfg) {
            ufo.color = uCfg.color || "#FF0033";
            ufo.speed = safeNum(uCfg.speed, 0.5, 30, ufo.speed);
        }

        // 弾の色の更新
        const bCfg = cfg.bullet || {};
        for (let b of playerBullets) {
            b.color = bCfg.playerBulletColor || "#00FF66";
        }
    }

    // ドット絵エディタからのリアルタイム更新受け口
    window.updateLiveSpritePreview = function(key, pattern) {
        if (!key || !pattern || !Array.isArray(pattern)) return;
        if (!window.GameConfig) window.GameConfig = {};
        if (!window.GameConfig.sprites) window.GameConfig.sprites = {};
        window.GameConfig.sprites[key] = pattern;

        // 自機スプライト更新時のサイズ反映
        if (key === "player") {
            const pDims = getSpriteDimensions(pattern, player.pixelSize);
            player.width = pDims.width;
            player.height = pDims.height;
        } else if (enemies && enemies.length > 0) {
            // 敵スプライト更新時の反映
            for (let e of enemies) {
                if (e.type === key) {
                    const dims = getSpriteDimensions(pattern, e.pixelSize);
                    e.width = dims.width;
                    e.height = dims.height;
                }
            }
        }

        // ホーム画面のプレビュー（「ゲーム開始」ボタン内アイコン、スコア表の敵アイコン）を即時更新！
        renderHomePreviewSprites();

        // ゲーム画面（キャンバス）も即時再描画
        draw();
    };

    // 設定変更時のリスタート用グローバル関数（IDEからの更新連携用）
    window.reloadGameWithNewConfig = function(newConfig) {
        if (newConfig) window.GameConfig = newConfig;

        if (gameState === "PAUSED") {
            // 一時停止中の場合: ゲーム進行を維持したまま、敵や自機の見た目・設定を即座に反映！
            applyConfigToActiveGame();
            renderHomePreviewSprites();
            draw();
            return;
        }

        const wasPlaying = (gameState !== "READY");
        difficultyChosen = false;
        wavesChosen = false;
        resetGame(true, wasPlaying);
        renderHomePreviewSprites();
    };
})();


// ============================================================================
// BUNDLED: 初心者向け Linter 診断エンジン
// ============================================================================
/**
 * linter.js - 初心者（中学生）向け 親切な構文エラー診断エンジン
 * 
 * 専門用語を使わず、「何が起きていて」「どこをどう直せばいいか」を平易な日本語で案内します。
 * 外部ライブラリ非依存（完全オフライン・Monaca対応）。
 */

(function (global) {
    'use strict';

    // 全角記号マップ（※日本語カタカナの長音「ー」は通常の日本語文字なので含めない）
    const FULLWIDTH_CHARS = {
        '\u3000': { name: '全角スペース', fix: '半角スペース' },
        '：': { name: '全角コロン', fix: '半角コロン「 : 」' },
        '，': { name: '全角カンマ', fix: '半角カンマ「 , 」' },
        '、': { name: '読点（、）', fix: '半角カンマ「 , 」' },
        '。': { name: '句点（。）', fix: '半角ピリオド「 . 」またはカンマ「 , 」' },
        '；': { name: '全角セミコロン', fix: '半角セミコロン「 ; 」' },
        '”': { name: '全角ダブルクォート', fix: '半角の「 " 」' },
        '“': { name: '全角ダブルクォート', fix: '半角の「 " 」' },
        '’': { name: '全角シングルクォート', fix: '半角の「 \' 」' },
        '‘': { name: '全角シングルクォート', fix: '半角の「 \' 」' },
        '｛': { name: '全角の波括弧', fix: '半角の「 { 」' },
        '｝': { name: '全角の波括弧', fix: '半角の「 } 」' },
        '［': { name: '全角の角括弧', fix: '半角の「 [ 」' },
        '］': { name: '全角の角括弧', fix: '半角の「 ] 」' },
        '（': { name: '全角の丸括弧', fix: '半角の「 ( 」' },
        '）': { name: '全角の丸括弧', fix: '半角の「 ) 」' },
        '＝': { name: '全角イコール', fix: '半角イコール「 = 」' },
        '＋': { name: '全角プラス', fix: '半角プラス「 + 」' },
        '－': { name: '全角マイナス', fix: '半角マイナス「 - 」' }, // \uFF0D
        '＊': { name: '全角アスタリスク', fix: '半角の「 * 」' },
        '／': { name: '全角スラッシュ', fix: '半角の「 / 」' },
        '＃': { name: '全角シャープ', fix: '半角の「 # 」' },
        '！': { name: '全角エクスクラメーション', fix: '半角の「 ! 」' },
        '？': { name: '全角クエスチョン', fix: '半角の「 ? 」' },
        '＜': { name: '全角の山括弧', fix: '半角の「 < 」' },
        '＞': { name: '全角の山括弧', fix: '半角の「 > 」' }
    };

    // config.js の既知スキーマ（タイポ検知用・実ファイル config.js と完全同期）
    const KNOWN_CONFIG_SCHEMA = {
        game: ['maxWaves', 'difficulty'],
        player: ['speed', 'color', 'lives', 'maxBullets', 'fireInterval'],
        bullet: ['speed', 'color', 'width', 'height'],
        enemy: ['rows', 'cols', 'speed', 'dropAmount', 'shootInterval', 'bulletSpeed', 'colors', 'scores'],
        bunker: ['enabled', 'count', 'width', 'height', 'color', 'regenerateEachWave', 'passThroughPlayer'],
        ufo: ['enabled', 'speed', 'bonusScore', 'score', 'interval', 'color'],
        sprites: ['player', 'squid', 'crab', 'octopus', 'ufo'],
        display: ['background', 'sound', 'canvasWidth', 'canvasHeight', 'scale']
    };

    const KNOWN_TOP_SECTIONS = Object.keys(KNOWN_CONFIG_SCHEMA);

    // HTMLの閉じタグ不要要素（void elements）
    const VOID_HTML_TAGS = new Set([
        'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
        'link', 'meta', 'param', 'source', 'track', 'wbr'
    ]);

    /**
     * 文字列の類似度（Levenshtein距離）
     */
    function levenshtein(a, b) {
        const matrix = [];
        for (let i = 0; i <= b.length; i++) matrix[i] = [i];
        for (let j = 0; j <= a.length; j++) matrix[0][j] = j;

        for (let i = 1; i <= b.length; i++) {
            for (let j = 1; j <= a.length; j++) {
                if (b.charAt(i - 1) === a.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1,
                        matrix[i][j - 1] + 1,
                        matrix[i - 1][j] + 1
                    );
                }
            }
        }
        return matrix[b.length][a.length];
    }

    /**
     * 文字列リテラルを考慮して一行コメント (//...) を除去する
     */
    function stripLineComment(line) {
        let inString = null;
        for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            const next = line[i + 1];
            if (inString) {
                if (ch === '\\') {
                    i++;
                } else if (ch === inString) {
                    inString = null;
                }
                continue;
            }
            if (ch === '"' || ch === "'" || ch === '`') {
                inString = ch;
                continue;
            }
            if (ch === '/' && next === '/') {
                return line.substring(0, i);
            }
        }
        return line;
    }

    /**
     * 変更された行（差分行）を検出する
     */
    function computeChangedLines(oldCode, newCode) {
        if (!oldCode || oldCode === newCode) return new Set();

        const oldLines = oldCode.split('\n');
        const newLines = newCode.split('\n');
        const changed = new Set();

        for (let i = 0; i < newLines.length; i++) {
            if (i >= oldLines.length || newLines[i] !== oldLines[i]) {
                changed.add(i + 1);
            }
        }

        return changed;
    }

    /**
     * エラーオブジェクトを生成
     */
    function createIssue(line, col, message, hint, severity, lineText, isChangedByUser) {
        return {
            line: Math.max(1, line || 1),
            col: Math.max(1, col || 1),
            message: message || '構文エラーがあります',
            hint: hint || '入力内容を確認してください',
            severity: severity || 'error', // 'error' | 'warning'
            lineText: lineText !== undefined ? lineText : '',
            isChangedByUser: !!isChangedByUser
        };
    }

    /**
     * 1. 全角記号・全角数字・全角英字チェック（コメント内・文字列内・HTMLテキスト内は完全に除外）
     */
    function checkFullwidthCharacters(filename, code) {
        const issues = [];
        const lines = code.split('\n');

        const isHtml = filename.endsWith('.html');
        const isJs = filename.endsWith('.js');

        let inHtmlComment = false;  // <!-- -->
        let inBlockComment = false; // /* */
        let inScriptTag = false;    // for HTML <script>
        let inStyleTag = false;     // for HTML <style>

        for (let i = 0; i < lines.length; i++) {
            const rawLine = lines[i];
            let inString = null; // '"', "'", or '`'
            let inHtmlTag = false;

            for (let c = 0; c < rawLine.length; c++) {
                const ch = rawLine[c];
                const next = rawLine[c + 1];
                const next3 = rawLine.substring(c, c + 4);
                const next2 = rawLine.substring(c, c + 3);

                // --- HTMLコメント判定 (<!-- ... -->) ---
                if (isHtml) {
                    if (inHtmlComment) {
                        if (next2 === '-->') {
                            inHtmlComment = false;
                            c += 2;
                        }
                        continue;
                    }
                    if (!inString && !inBlockComment && next3 === '<!--') {
                        inHtmlComment = true;
                        c += 3;
                        continue;
                    }

                    // <script> と <style> の出入り
                    if (!inString && !inBlockComment) {
                        const lowerRest = rawLine.substring(c).toLowerCase();
                        if (lowerRest.startsWith('<script')) inScriptTag = true;
                        if (lowerRest.startsWith('</script>')) inScriptTag = false;
                        if (lowerRest.startsWith('<style')) inStyleTag = true;
                        if (lowerRest.startsWith('</style>')) inStyleTag = false;

                        if (ch === '<') inHtmlTag = true;
                        if (ch === '>') {
                            inHtmlTag = false;
                            continue;
                        }
                    }

                    // HTMLで、タグの外側（通常の日本語テキスト）かつscript/style外は全角チェック不要
                    if (!inHtmlTag && !inScriptTag && !inStyleTag) {
                        continue;
                    }
                }

                // --- ブロックコメント中 (/* ... */) ---
                if (inBlockComment) {
                    if (ch === '*' && next === '/') {
                        inBlockComment = false;
                        c++;
                    }
                    continue;
                }

                // --- 文字列リテラル判定 (", ', `) ※コメント開始判定より先に行う ---
                if (inString) {
                    if (ch === '\\') {
                        c++; // エスケープ
                    } else if (ch === inString) {
                        inString = null; // 文字列終了
                    }
                    // 文字列リテラル内の全角文字は完全に許容
                    continue;
                }

                // --- JS / CSS / HTML内script・style のコメント開始判定 ---
                const inJsContext = isJs || (isHtml && inScriptTag && !inHtmlTag);
                const inCssContext = filename.endsWith('.css') || (isHtml && inStyleTag && !inHtmlTag);

                if (inJsContext || inCssContext) {
                    if (ch === '/' && next === '*') {
                        inBlockComment = true;
                        c++;
                        continue;
                    }
                    if (inJsContext && ch === '/' && next === '/') {
                        // 一行コメント以降は行末まで完全にスキップ
                        break;
                    }
                }

                if (ch === '"' || ch === "'" || (inJsContext && ch === '`')) {
                    inString = ch;
                    continue;
                }

                // --- 全角記号チェック ---
                if (FULLWIDTH_CHARS[ch]) {
                    const info = FULLWIDTH_CHARS[ch];
                    issues.push(createIssue(
                        i + 1,
                        c + 1,
                        `全角の「${ch}」(${info.name}) が使われています`,
                        `キーボードを半角入力にして、${info.fix} に書き直してください`,
                        'error',
                        rawLine
                    ));
                    continue;
                }

                // --- 全角数字チェック (コメント・文字列外のみ) ---
                if (ch >= '０' && ch <= '９') {
                    issues.push(createIssue(
                        i + 1,
                        c + 1,
                        `全角数字の「${ch}」が入力されています`,
                        `半角数字の「${String.fromCharCode(ch.charCodeAt(0) - 0xFEE0)}」に書き直してください`,
                        'error',
                        rawLine
                    ));
                    continue;
                }

                // --- 全角アルファベットチェック (コメント・文字列外のみ) ---
                if ((ch >= 'Ａ' && ch <= 'Ｚ') || (ch >= 'ａ' && ch <= 'ｚ')) {
                    const halfChar = String.fromCharCode(ch.charCodeAt(0) - 0xFEE0);
                    issues.push(createIssue(
                        i + 1,
                        c + 1,
                        `全角アルファベットの「${ch}」が入力されています`,
                        `キーボードを半角英数にして、半角の「${halfChar}」に書き直してください`,
                        'error',
                        rawLine
                    ));
                    continue;
                }
            }
        }

        return issues;
    }

    /**
     * 2. クォート閉じ忘れチェック（コメント外のみ）
     */
    function checkUnclosedQuotes(filename, code) {
        if (filename.endsWith('.html')) return []; // HTMLは checkHTML 内で属性・タグごとに検査

        const issues = [];
        const lines = code.split('\n');
        let inMultiComment = false;

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            let inString = null;
            let startCol = 0;

            for (let c = 0; c < line.length; c++) {
                const ch = line[c];
                const next = line[c + 1];

                if (inMultiComment) {
                    if (ch === '*' && next === '/') {
                        inMultiComment = false;
                        c++;
                    }
                    continue;
                }

                if (inString) {
                    if (ch === '\\') {
                        c++;
                    } else if (ch === inString) {
                        inString = null;
                    }
                    continue;
                }

                if (ch === '/' && next === '*') {
                    inMultiComment = true;
                    c++;
                    continue;
                }

                if (ch === '/' && next === '/') {
                    break; // 一行コメント
                }

                if (ch === '"' || ch === "'") {
                    inString = ch;
                    startCol = c + 1;
                }
            }

            if (inString && !inMultiComment) {
                issues.push(createIssue(
                    i + 1,
                    startCol,
                    `文字列を囲む「 ${inString} 」が閉じていません`,
                    `値の最後に「 ${inString} 」を付けて正しく閉じてください`,
                    'error',
                    line
                ));
            }
        }

        return issues;
    }

    /**
     * 3. 括弧の対応チェック ({ }, [ ], ( ))
     */
    function checkBracketPairs(filename, code) {
        // HTMLはタグ体系が別なので対象外
        if (filename.endsWith('.html')) return [];

        const issues = [];
        const stack = [];
        const lines = code.split('\n');
        let inBlockComment = false;

        const BRACKET_PAIRS = {
            '}': { open: '{', name: '波括弧 { }' },
            ']': { open: '[', name: '角括弧 [ ]' },
            ')': { open: '(', name: '丸括弧 ( )' }
        };

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            let inString = null;

            for (let c = 0; c < line.length; c++) {
                const ch = line[c];
                const next = line[c + 1];

                if (inBlockComment) {
                    if (ch === '*' && next === '/') {
                        inBlockComment = false;
                        c++;
                    }
                    continue;
                }

                if (inString) {
                    if (ch === '\\') {
                        c++;
                    } else if (ch === inString) {
                        inString = null;
                    }
                    continue;
                }

                if (ch === '/' && next === '/') break;
                if (ch === '/' && next === '*') {
                    inBlockComment = true;
                    c++;
                    continue;
                }

                if (ch === '"' || ch === "'" || ch === '`') {
                    inString = ch;
                    continue;
                }

                if (ch === '{' || ch === '[' || ch === '(') {
                    stack.push({ char: ch, line: i + 1, col: c + 1, lineText: line });
                } else if (ch === '}' || ch === ']' || ch === ')') {
                    const expected = BRACKET_PAIRS[ch];
                    if (stack.length === 0) {
                        issues.push(createIssue(
                            i + 1,
                            c + 1,
                            `余分な閉じ括弧「 ${ch} 」があります`,
                            `対応する開き括弧がないため、この「 ${ch} 」を削除するか確認してください`,
                            'error',
                            line
                        ));
                    } else {
                        const top = stack.pop();
                        if (top.char !== expected.open) {
                            issues.push(createIssue(
                                i + 1,
                                c + 1,
                                `括弧の種類が一致していません（行 ${top.line} の「${top.char}」に対して「${ch}」で閉じています）`,
                                `「${top.char}」に対応する正しい閉じ括弧を使用してください`,
                                'error',
                                line
                            ));
                        }
                    }
                }
            }
        }

        while (stack.length > 0) {
            const unclosed = stack.pop();
            const pairName = unclosed.char === '{' ? '波括弧「 } 」' : (unclosed.char === '[' ? '角括弧「 ] 」' : '丸括弧「 ) 」');
            issues.push(createIssue(
                unclosed.line,
                unclosed.col,
                `開き括弧「 ${unclosed.char} 」が最後まで閉じられていません`,
                `対応する位置に閉じ括弧 ${pairName} を追加してください`,
                'error',
                unclosed.lineText
            ));
        }

        return issues;
    }

    /**
     * 4. config.js 固有の初心者ミス＆タイポ・実行時エラー検知
     */
    function checkConfigSchemaAndTraps(code, changedLines) {
        const issues = [];
        const lines = code.split('\n');

        let currentSection = null;
        let inBlockComment = false;

        // 事前に各行のコメント除去済みテキストを計算
        const cleanLines = lines.map(rawLine => {
            let line = rawLine;
            if (inBlockComment) {
                const closeIdx = line.indexOf('*/');
                if (closeIdx !== -1) {
                    inBlockComment = false;
                    line = line.substring(closeIdx + 2);
                } else {
                    return '';
                }
            }
            while (true) {
                const openIdx = line.indexOf('/*');
                if (openIdx === -1) break;
                const closeIdx = line.indexOf('*/', openIdx + 2);
                if (closeIdx !== -1) {
                    line = line.substring(0, openIdx) + line.substring(closeIdx + 2);
                } else {
                    inBlockComment = true;
                    line = line.substring(0, openIdx);
                    break;
                }
            }
            return stripLineComment(line).trim();
        });

        for (let i = 0; i < lines.length; i++) {
            const rawLine = lines[i];
            const clean = cleanLines[i];
            if (!clean) continue;

            // セクション開始の検知 (例: player: {, bullet: {)
            const sectionMatch = clean.match(/^([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:\s*\{/);
            if (sectionMatch) {
                const secName = sectionMatch[1];
                if (!KNOWN_CONFIG_SCHEMA[secName]) {
                    let closestSec = null;
                    let minDist = 999;
                    for (const knownSec of KNOWN_TOP_SECTIONS) {
                        const d = levenshtein(secName.toLowerCase(), knownSec.toLowerCase());
                        if (d < minDist) {
                            minDist = d;
                            closestSec = knownSec;
                        }
                    }
                    if (minDist <= 3) {
                        issues.push(createIssue(
                            i + 1,
                            rawLine.indexOf(secName) + 1,
                            `「${secName}」という設定カテゴリはありません（「${closestSec}」のスペルミスではありませんか？）`,
                            `カテゴリ名を「${closestSec}」に書き直してください`,
                            'error',
                            rawLine
                        ));
                    }
                }
                currentSection = secName;
                continue;
            }

            // 代入記号イコールの誤用 (speed = 5)
            const assignMatch = clean.match(/^([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=\s*(.+)$/);
            if (assignMatch && !clean.startsWith('const ') && !clean.startsWith('let ') && !clean.startsWith('var ')) {
                issues.push(createIssue(
                    i + 1,
                    rawLine.indexOf('=') + 1,
                    `オブジェクトの設定では「 = 」ではなく「 : 」（コロン）を使います`,
                    `「 ${assignMatch[1]}: ${assignMatch[2]} 」のようにコロンに書き直してください`,
                    'error',
                    rawLine
                ));
                continue;
            }

            // コロン抜け (speed 5)
            const missingColonMatch = clean.match(/^([a-zA-Z_$][a-zA-Z0-9_$]*)\s+([0-9"'{[a-zA-Z#-])/);
            if (missingColonMatch && !clean.startsWith('return ') && !clean.startsWith('const ') && !clean.startsWith('let ') && !clean.startsWith('var ')) {
                issues.push(createIssue(
                    i + 1,
                    rawLine.indexOf(missingColonMatch[1]) + missingColonMatch[1].length + 1,
                    `項目名「${missingColonMatch[1]}」の後にコロン（:）がありません`,
                    `「${missingColonMatch[1]}: 」のようにコロンを付けて値を指定してください`,
                    'error',
                    rawLine
                ));
                continue;
            }

            // 値の抜け (speed: , または difficulty: のようにコロンの後に値がない)
            if (/^[a-zA-Z_$][a-zA-Z0-9_$]*\s*:\s*[,;]?\s*$/.test(clean)) {
                issues.push(createIssue(
                    i + 1,
                    rawLine.indexOf(':') + 1,
                    `設定値が入力されていません（コロンの後に値がありません）`,
                    `コロンの後に数値や文字列（"..."）などの設定値を入力してください`,
                    'error',
                    rawLine
                ));
                continue;
            }

            // カラーコードのクォート忘れ (color: #00FF66 または配列内の #FFFF00)
            const unquotedHexProp = clean.match(/^[a-zA-Z_$][a-zA-Z0-9_$]*\s*:\s*(#[0-9a-fA-F]{3,8})\b/);
            const unquotedHexElem = clean.match(/^(#[0-9a-fA-F]{3,8})\s*,?$/);
            if (unquotedHexProp || unquotedHexElem) {
                const hex = (unquotedHexProp || unquotedHexElem)[1];
                issues.push(createIssue(
                    i + 1,
                    rawLine.indexOf(hex) + 1,
                    `カラーコード「${hex}」がダブルクォート（" "）で囲まれていません`,
                    `色のコードは「 "${hex}" 」のように半角の「 " 」で囲んで指定してください`,
                    'error',
                    rawLine
                ));
                continue;
            }

            // プロパティキーの検知と値チェック (例: maxBullets: 8,)
            const propMatch = clean.match(/^([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:\s*(.+?)\s*([,;]?)$/);
            if (propMatch && currentSection && KNOWN_CONFIG_SCHEMA[currentSection]) {
                const key = propMatch[1];
                const rawVal = propMatch[2].replace(/,\s*$/, '').trim();
                const knownKeys = KNOWN_CONFIG_SCHEMA[currentSection];

                if (!knownKeys.includes(key)) {
                    let closest = null;
                    let minDistance = 999;
                    for (const known of knownKeys) {
                        const dist = levenshtein(key.toLowerCase(), known.toLowerCase());
                        if (dist < minDistance) {
                            minDistance = dist;
                            closest = known;
                        }
                    }

                    const isChanged = changedLines && changedLines.has(i + 1);
                    if (minDistance <= 3 || isChanged) {
                        issues.push(createIssue(
                            i + 1,
                            rawLine.indexOf(key) + 1,
                            `「${key}」という設定項目はありません（「${closest}」のスペルミスではありませんか？）`,
                            `「${currentSection}」には「${closest}」を指定してください（例: ${closest}: ...）`,
                            'error',
                            rawLine,
                            isChanged
                        ));
                    }
                }

                // 値の未クォート単語・スペルミス判定 (例: difficulty: normal, enabled: ture, background: space-bg)
                if (rawVal && !rawVal.startsWith('{') && !rawVal.startsWith('[')) {
                    const isQuoted = (rawVal.startsWith('"') && rawVal.endsWith('"')) ||
                                     (rawVal.startsWith("'") && rawVal.endsWith("'")) ||
                                     (rawVal.startsWith('`') && rawVal.endsWith('`'));
                    const isNumber = /^-?\d+(\.\d+)?$/.test(rawVal);
                    const isBoolean = rawVal === 'true' || rawVal === 'false';
                    const isNullOrUndefined = rawVal === 'null' || rawVal === 'undefined';

                    if (!isQuoted && !isNumber && !isBoolean && !isNullOrUndefined) {
                        // true / false のスペルミスかチェック
                        const distTrue = levenshtein(rawVal.toLowerCase(), 'true');
                        const distFalse = levenshtein(rawVal.toLowerCase(), 'false');
                        if (distTrue <= 2 && rawVal !== 'true') {
                            issues.push(createIssue(
                                i + 1,
                                rawLine.lastIndexOf(rawVal) + 1,
                                `設定値「${rawVal}」は使えません（「true」のスペルミスではありませんか？）`,
                                `ONにする場合は半角小文字で「 true 」、OFFにする場合は「 false 」と入力してください`,
                                'error',
                                rawLine
                            ));
                        } else if (distFalse <= 2 && rawVal !== 'false') {
                            issues.push(createIssue(
                                i + 1,
                                rawLine.lastIndexOf(rawVal) + 1,
                                `設定値「${rawVal}」は使えません（「false」のスペルミスではありませんか？）`,
                                `OFFにする場合は半角小文字で「 false 」、ONにする場合は「 true 」と入力してください`,
                                'error',
                                rawLine
                            ));
                        } else if (/^[a-zA-Z0-9_$-]+$/.test(rawVal)) {
                            issues.push(createIssue(
                                i + 1,
                                rawLine.lastIndexOf(rawVal) + 1,
                                `文字の設定値「${rawVal}」がダブルクォート（" "）で囲まれていません`,
                                `文字を指定するときは「 "${rawVal}" 」のように半角の「 " 」で囲んでください`,
                                'error',
                                rawLine
                            ));
                        }
                    }
                }
            }

            // カンマ抜けチェック（次の有効行との関係を検査）
            let nextIndex = -1;
            for (let j = i + 1; j < lines.length; j++) {
                if (cleanLines[j]) {
                    nextIndex = j;
                    break;
                }
            }

            if (nextIndex !== -1) {
                const nextClean = cleanLines[nextIndex];
                const lastChar = clean.slice(-1);
                const nextIsProperty = /^[a-zA-Z_$][a-zA-Z0-9_$]*\s*:/.test(nextClean);
                const nextIsArrayItem = /^(".*"|'.*'|-?\d+(\.\d+)?)\s*,?$/.test(nextClean);

                // 1) プロパティ行の後ろに別のプロパティ行が続くのにカンマがない
                const isPropertyLine = /^[a-zA-Z_$][a-zA-Z0-9_$]*\s*:\s*.+$/.test(clean);
                if (isPropertyLine && lastChar !== ',' && lastChar !== '{' && lastChar !== '[' && lastChar !== '(') {
                    if (nextIsProperty) {
                        issues.push(createIssue(
                            i + 1,
                            rawLine.length,
                            `行末のカンマ（,）が抜けています`,
                            `この行の末尾に「 , 」を追加してください（次の項目と区切るためにカンマが必要です）`,
                            'error',
                            rawLine
                        ));
                    }
                }

                // 2) オブジェクト閉じ「}」または配列閉じ「]」の後ろに次のプロパティが続くのにカンマがない
                if ((clean === '}' || clean === ']') && nextIsProperty) {
                    issues.push(createIssue(
                        i + 1,
                        rawLine.length,
                        `閉じ括弧「 ${clean} 」の後ろにカンマ（,）が抜けています`,
                        `「 ${clean}, 」のようにカンマを付けて、次の設定項目と区切ってください`,
                        'error',
                        rawLine
                    ));
                }

                // 3) 配列要素（文字列や数値）の後ろに次の配列要素が続くのにカンマがない
                const isArrayItemLine = /^(".*"|'.*'|-?\d+(\.\d+)?)$/.test(clean);
                if (isArrayItemLine && nextIsArrayItem) {
                    issues.push(createIssue(
                        i + 1,
                        rawLine.length,
                        `配列データの行末にカンマ（,）が抜けています`,
                        `この行の末尾に「 , 」を追加してください（データを並べるにはカンマで区切る必要があります）`,
                        'error',
                        rawLine
                    ));
                }
            }
        }

        return issues;
    }

    /**
     * コード断片の未閉じ括弧を自動補完する文字列を返す（行番号特定用）
     */
    function getAutoCloseBrackets(code) {
        const stack = [];
        let inBlockComment = false;
        let inString = null;

        for (let i = 0; i < code.length; i++) {
            const ch = code[i];
            const next = code[i + 1];

            if (inBlockComment) {
                if (ch === '*' && next === '/') {
                    inBlockComment = false;
                    i++;
                }
                continue;
            }
            if (inString) {
                if (ch === '\\') {
                    i++;
                } else if (ch === inString) {
                    inString = null;
                }
                continue;
            }
            if (ch === '/' && next === '/') {
                while (i < code.length && code[i] !== '\n') i++;
                continue;
            }
            if (ch === '/' && next === '*') {
                inBlockComment = true;
                i++;
                continue;
            }
            if (ch === '"' || ch === "'" || ch === '`') {
                inString = ch;
                continue;
            }
            if (ch === '{') stack.push('}');
            else if (ch === '[') stack.push(']');
            else if (ch === '(') stack.push(')');
            else if (ch === '}' || ch === ']' || ch === ')') {
                if (stack.length > 0 && stack[stack.length - 1] === ch) {
                    stack.pop();
                }
            }
        }
        return stack.reverse().join('');
    }

    /**
     * 5. JS構文解析＆正確なエラー行特定
     */
    function checkJavaScriptNativeSyntax(code, changedLines, isConfig) {
        try {
            new Function(code);
        } catch (err) {
            const rawMsg = err.message || '';
            const lines = code.split('\n');

            let userMessage = 'JavaScriptの構文エラーがあります';
            let userHint = '直前の行のカンマ（,）や括弧の閉じ忘れを確認してください';

            if (rawMsg.includes('Unexpected token')) {
                if (rawMsg.includes("','")) {
                    userMessage = '不要なカンマ（,）があるか、記号の使い方が間違っています';
                    userHint = '余分なカンマを消すか、カンマの前の値を確認してください';
                } else if (rawMsg.includes("'}'")) {
                    userMessage = '波括弧「 } 」の位置が不正か、直前の行に値がありません';
                    userHint = '直前の行でコロンの後に値が抜けているか、余分な閉じ括弧がないか確認してください';
                } else if (rawMsg.includes("']'")) {
                    userMessage = '角括弧「 ] 」の位置が不正です';
                    userHint = '配列内のカンマや閉じ括弧の位置を確認してください';
                } else if (rawMsg.includes("':'")) {
                    userMessage = 'コロン（:）の位置が不正です';
                    userHint = '前の行のカンマ抜けや、波括弧「 { } 」の閉じ忘れがないか確認してください';
                } else {
                    userMessage = `記号または単語の使い方が不正です（${rawMsg}）`;
                    userHint = '綴りミスや記号の位置を確認してください';
                }
            } else if (rawMsg.includes('Unexpected identifier')) {
                userMessage = 'カンマ（,）が抜けているか、文字が「" "」で囲まれていません';
                userHint = '前の行の末尾にカンマ「 , 」があるか、または文字列を「 " " 」で囲んでいるか確認してください';
            } else if (rawMsg.includes('Unexpected number')) {
                userMessage = '数値の位置が不正です';
                userHint = '前の行の末尾にカンマ「 , 」があるか、数値の前にコロン「 : 」があるか確認してください';
            } else if (rawMsg.includes('Unexpected string')) {
                userMessage = '文字列の位置が不正です（前の行のカンマ抜けの可能性があります）';
                userHint = '直前の行の末尾にカンマ「 , 」が抜けていないか確認してください';
            } else if (rawMsg.includes('Unexpected end of input')) {
                userMessage = 'コードが途中で終わっています（括弧やクォートが閉じられていません）';
                userHint = 'ファイル全体の「 { } 」「 [ ] 」のペアがすべて閉じているか確認してください';
            } else if (rawMsg.includes('Invalid or unexpected token') || rawMsg.includes('Private field')) {
                userMessage = '使えない記号があるか、カラーコード等が「" "」で囲まれていません';
                userHint = '色コード（"#00FF66" など）を「 " " 」で囲んでいるか、全角文字がないか確認してください';
            }

            let errorLine = findSyntaxErrorLine(lines);
            if (changedLines && changedLines.size > 0) {
                for (const line of changedLines) {
                    if (Math.abs(line - errorLine) <= 2) {
                        errorLine = line;
                        userHint += `（あなたが編集した 行 ${line} 付近を確認してください）`;
                        break;
                    }
                }
            }

            return [createIssue(
                errorLine,
                1,
                userMessage,
                userHint,
                'error',
                lines[errorLine - 1] || '',
                changedLines ? changedLines.has(errorLine) : false
            )];
        }

        // config.js の場合は実際に評価して ReferenceError（未定義の単語・クォート忘れ等）も捕捉する
        if (isConfig) {
            try {
                const cfg = new Function(code + '\n; return typeof GameConfig !== "undefined" ? GameConfig : null;')();
                if (!cfg || typeof cfg !== 'object') {
                    return [createIssue(
                        1,
                        1,
                        'GameConfig の定義が見つかりません',
                        '「const GameConfig = { ... };」の名前を消していないか確認してください',
                        'error',
                        lines[0] || '',
                        false
                    )];
                }
            } catch (runtimeErr) {
                const msg = runtimeErr.message || '';
                const lines = code.split('\n');
                const notDefinedMatch = msg.match(/^(.+?) is not defined$/);
                if (notDefinedMatch) {
                    const badWord = notDefinedMatch[1];
                    let foundLine = 1;
                    const wordRegex = new RegExp(`\\b${badWord.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`);
                    for (let i = 0; i < lines.length; i++) {
                        const clean = stripLineComment(lines[i]);
                        if (wordRegex.test(clean)) {
                            foundLine = i + 1;
                            break;
                        }
                    }
                    return [createIssue(
                        foundLine,
                        1,
                        `「${badWord}」という設定値はそのままでは使えません`,
                        `文字列なら「 "${badWord}" 」のように半角の「 " 」で囲み、ON/OFFなら「 true 」「 false 」と入力してください`,
                        'error',
                        lines[foundLine - 1] || '',
                        changedLines ? changedLines.has(foundLine) : false
                    )];
                }
            }
        }

        return [];
    }

    function findSyntaxErrorLine(lines) {
        for (let i = 1; i <= lines.length; i++) {
            const rawLine = lines[i - 1];
            const trimmed = stripLineComment(rawLine).trim();
            // 空行や次行へ続く演算子末尾の行はスキップ
            if (!trimmed || /[+\-*/&|=?:,(.$]$/.test(trimmed)) continue;

            const subCode = lines.slice(0, i).join('\n');
            const autoClose = getAutoCloseBrackets(subCode);
            try {
                new Function(subCode + '\n' + autoClose);
            } catch (e) {
                const msg = e.message || '';
                if (!msg.includes('Unexpected end of input') &&
                    !msg.includes('Missing catch or finally after try')) {
                    // カンマ抜け等で「次の行の先頭」でエラーが出た場合、直前の行に原因があることが多い
                    if (i > 1 && (msg.includes('Unexpected identifier') || msg.includes('Unexpected string') || msg.includes('Unexpected number'))) {
                        const prevClean = stripLineComment(lines[i - 2]).trim();
                        if (prevClean && !prevClean.endsWith(',') && !prevClean.endsWith('{') && !prevClean.endsWith('[') && !prevClean.endsWith(';') && !prevClean.endsWith('(')) {
                            return i - 1;
                        }
                    }
                    return i;
                }
            }
        }
        return lines.length;
    }

    /**
     * 6. CSS (style.css) チェック
     */
    function checkCSS(code) {
        const issues = [];
        const lines = code.split('\n');
        let inBlockComment = false;
        let braceDepth = 0;

        for (let i = 0; i < lines.length; i++) {
            const rawLine = lines[i];
            let line = rawLine;

            if (inBlockComment) {
                const closeIdx = line.indexOf('*/');
                if (closeIdx !== -1) {
                    inBlockComment = false;
                    line = line.substring(closeIdx + 2);
                } else {
                    continue;
                }
            }
            while (true) {
                const openIdx = line.indexOf('/*');
                if (openIdx === -1) break;
                const closeIdx = line.indexOf('*/', openIdx + 2);
                if (closeIdx !== -1) {
                    line = line.substring(0, openIdx) + line.substring(closeIdx + 2);
                } else {
                    inBlockComment = true;
                    line = line.substring(0, openIdx);
                    break;
                }
            }

            const trimmed = line.trim();
            if (!trimmed) continue;

            const hasOpenBrace = trimmed.includes('{');
            const hasCloseBrace = trimmed.includes('}');

            if (!hasOpenBrace && !hasCloseBrace && braceDepth > 0) {
                // ルール内部のプロパティ行
                if (trimmed.includes(':')) {
                    const colonIdx = trimmed.indexOf(':');
                    const valPart = trimmed.substring(colonIdx + 1).replace(/;/g, '').trim();
                    if (!valPart) {
                        issues.push(createIssue(
                            i + 1,
                            rawLine.indexOf(':') + 1,
                            `CSSのプロパティ値が入力されていません`,
                            `コロン（:）の後に色やサイズなどの値を入力してください（例: color: #ffffff;）`,
                            'error',
                            rawLine
                        ));
                    } else if (!trimmed.endsWith(';') && !trimmed.endsWith(',')) {
                        issues.push(createIssue(
                            i + 1,
                            rawLine.length,
                            `CSSプロパティ末尾のセミコロン（;）が抜けています`,
                            `行末に「 ; 」を追加してください（例: color: red;）`,
                            'error',
                            rawLine
                        ));
                    }
                } else if (/^[a-zA-Z-]+\s+[^,{]+$/.test(trimmed)) {
                    issues.push(createIssue(
                        i + 1,
                        rawLine.indexOf(trimmed) + 1,
                        `CSSのプロパティ名と値の間にコロン（:）がありません`,
                        `「 プロパティ名: 値; 」のようにコロン（:）で区切ってください`,
                        'error',
                        rawLine
                    ));
                }
            }

            for (let c = 0; c < trimmed.length; c++) {
                if (trimmed[c] === '{') braceDepth++;
                else if (trimmed[c] === '}') braceDepth = Math.max(0, braceDepth - 1);
            }
        }

        return issues;
    }

    /**
     * 7. HTML (index.html) チェック（タグ対応・属性クォート・未閉じ山括弧・インラインScript）
     */
    function checkHTML(code, changedLines) {
        const issues = [];
        const lines = code.split('\n');

        let inComment = false;
        let inScript = false;
        let inStyle = false;
        let scriptLines = [];
        let scriptStartLine = 0;
        const tagStack = [];

        for (let i = 0; i < lines.length; i++) {
            const rawLine = lines[i];
            let line = rawLine;

            // コメント処理 (<!-- ... -->)
            if (inComment) {
                const closeIdx = line.indexOf('-->');
                if (closeIdx !== -1) {
                    inComment = false;
                    line = line.substring(closeIdx + 3);
                } else {
                    continue;
                }
            }
            while (true) {
                const openIdx = line.indexOf('<!--');
                if (openIdx === -1) break;
                const closeIdx = line.indexOf('-->', openIdx + 4);
                if (closeIdx !== -1) {
                    line = line.substring(0, openIdx) + line.substring(closeIdx + 3);
                } else {
                    inComment = true;
                    line = line.substring(0, openIdx);
                    break;
                }
            }

            // <script> 内の収集と終了チェック
            if (inScript) {
                const closeMatch = line.match(/<\/script\s*>/i);
                if (closeMatch) {
                    inScript = false;
                    if (scriptLines.length > 0) {
                        const scriptCode = scriptLines.join('\n');
                        const jsIssues = checkJavaScriptNativeSyntax(scriptCode, null, false);
                        jsIssues.forEach(item => {
                            issues.push(createIssue(
                                scriptStartLine + item.line,
                                item.col,
                                `<script>内のエラー: ${item.message}`,
                                item.hint,
                                'error',
                                lines[scriptStartLine + item.line - 1] || ''
                            ));
                        });
                        scriptLines = [];
                    }
                    const top = tagStack.length > 0 && tagStack[tagStack.length - 1].tag === 'script' ? tagStack.pop() : null;
                    line = line.substring(closeMatch.index + closeMatch[0].length);
                } else {
                    scriptLines.push(rawLine);
                    continue;
                }
            }

            // <style> 内のスキップと終了チェック
            if (inStyle) {
                const closeMatch = line.match(/<\/style\s*>/i);
                if (closeMatch) {
                    inStyle = false;
                    if (tagStack.length > 0 && tagStack[tagStack.length - 1].tag === 'style') {
                        tagStack.pop();
                    }
                    line = line.substring(closeMatch.index + closeMatch[0].length);
                } else {
                    continue;
                }
            }

            // 行内のタグと属性クォートを走査
            let pos = 0;
            while (pos < line.length) {
                const ltIdx = line.indexOf('<', pos);
                if (ltIdx === -1) break;

                // '<' から '>' までを探す（クォート内を考慮）
                let gtIdx = -1;
                let quoteChar = null;
                let quoteStartCol = 0;
                for (let k = ltIdx + 1; k < line.length; k++) {
                    const ch = line[k];
                    if (quoteChar) {
                        if (ch === quoteChar) quoteChar = null;
                    } else {
                        if (ch === '"' || ch === "'") {
                            quoteChar = ch;
                            quoteStartCol = k + 1;
                        } else if (ch === '>') {
                            gtIdx = k;
                            break;
                        } else if (ch === '<') {
                            break;
                        }
                    }
                }

                if (quoteChar) {
                    issues.push(createIssue(
                        i + 1,
                        quoteStartCol,
                        `HTMLタグ内の属性を囲む「 ${quoteChar} 」が閉じていません`,
                        `属性値の最後に「 ${quoteChar} 」と「 > 」があるか確認してください`,
                        'error',
                        rawLine
                    ));
                    break;
                }

                if (gtIdx === -1) {
                    issues.push(createIssue(
                        i + 1,
                        ltIdx + 1,
                        `HTMLタグの「 < 」に対応する閉じ「 > 」がありません`,
                        `タグの最後に「 > 」を追加してください`,
                        'error',
                        rawLine
                    ));
                    break;
                }

                const tagContent = line.substring(ltIdx + 1, gtIdx).trim();
                pos = gtIdx + 1;

                if (!tagContent || tagContent.startsWith('!')) continue; // <!DOCTYPE html> 等

                const isClosing = tagContent.startsWith('/');
                const isSelfClosing = tagContent.endsWith('/');
                const nameMatch = tagContent.replace(/^\//, '').match(/^([a-zA-Z0-9-]+)/);
                if (!nameMatch) continue;

                const tagName = nameMatch[1].toLowerCase();
                if (VOID_HTML_TAGS.has(tagName) || isSelfClosing) continue;

                if (!isClosing) {
                    tagStack.push({ tag: tagName, line: i + 1, col: ltIdx + 1, lineText: rawLine });
                    if (tagName === 'script') {
                        const hasSrc = /\bsrc\s*=/i.test(tagContent);
                        const restOfLine = line.substring(pos);
                        const sameLineClose = restOfLine.match(/<\/script\s*>/i);
                        if (sameLineClose) {
                            tagStack.pop();
                            pos += sameLineClose.index + sameLineClose[0].length;
                        } else {
                            inScript = true;
                            scriptLines = [];
                            scriptStartLine = i + 1;
                            if (hasSrc) {
                                // src付きの <script src="..."> で同じ行に </script> がない場合
                            }
                            break;
                        }
                    } else if (tagName === 'style') {
                        const restOfLine = line.substring(pos);
                        const sameLineClose = restOfLine.match(/<\/style\s*>/i);
                        if (sameLineClose) {
                            tagStack.pop();
                            pos += sameLineClose.index + sameLineClose[0].length;
                        } else {
                            inStyle = true;
                            break;
                        }
                    }
                } else {
                    if (tagStack.length === 0) {
                        issues.push(createIssue(
                            i + 1,
                            ltIdx + 1,
                            `対応する開始タグがない閉じタグ </${tagName}> があります`,
                            `<${tagName}> が消えていないか、または余分な </${tagName}> でないか確認してください`,
                            'error',
                            rawLine
                        ));
                    } else {
                        const top = tagStack[tagStack.length - 1];
                        if (top.tag === tagName) {
                            tagStack.pop();
                        } else {
                            // スタック内に一致する開始タグがあるか探す（途中のタグの閉じ忘れ）
                            let matchIdx = -1;
                            for (let s = tagStack.length - 1; s >= 0; s--) {
                                if (tagStack[s].tag === tagName) {
                                    matchIdx = s;
                                    break;
                                }
                            }
                            if (matchIdx !== -1) {
                                while (tagStack.length > matchIdx + 1) {
                                    const unclosed = tagStack.pop();
                                    issues.push(createIssue(
                                        unclosed.line,
                                        unclosed.col,
                                        `<${unclosed.tag}> タグが閉じられていません（</${unclosed.tag}> が抜けています）`,
                                        `行 ${unclosed.line} の <${unclosed.tag}> に対応する </${unclosed.tag}> を追加してください`,
                                        'error',
                                        unclosed.lineText
                                    ));
                                }
                                tagStack.pop();
                            } else {
                                issues.push(createIssue(
                                    i + 1,
                                    ltIdx + 1,
                                    `タグの対応が一致していません（<${top.tag}> に対して </${tagName}> で閉じています）`,
                                    `</${top.tag}> で閉じるか、タグ名を確認してください`,
                                    'error',
                                    rawLine
                                ));
                            }
                        }
                    }
                }
            }
        }

        while (tagStack.length > 0) {
            const unclosed = tagStack.pop();
            issues.push(createIssue(
                unclosed.line,
                unclosed.col,
                `<${unclosed.tag}> タグが正しく閉じられていません（</${unclosed.tag}> がありません）`,
                `行 ${unclosed.line} で開いた <${unclosed.tag}> に対応する </${unclosed.tag}> を追加してください`,
                'error',
                unclosed.lineText
            ));
        }

        return issues;
    }

    /**
     * 8. 未復元箇所 (TODO) の警告検知
     */
    function checkTodoWarnings(code) {
        const warnings = [];
        const lines = code.split('\n');

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            if (line.includes('TODO')) {
                warnings.push(createIssue(
                    i + 1,
                    line.indexOf('TODO') + 1,
                    `未復元の箇所 (TODO) があります`,
                    `この行の設定値を確認して、指示に従って数値を入力してみましょう`,
                    'warning',
                    line
                ));
            }
        }

        return warnings;
    }

    /**
     * メイン診断関数
     * @param {string} filename ファイル名 (config.js, style.css, etc.)
     * @param {string} code コード文字列
     * @param {Object} options オプション { baselineCode, changedLines }
     * @returns {Array} 発見された問題の配列
     */
    function lint(filename, code, options) {
        if (!code || typeof code !== 'string') return [];

        options = options || {};
        let changedLines = options.changedLines;
        if (!changedLines && options.baselineCode) {
            changedLines = computeChangedLines(options.baselineCode, code);
        }

        let issues = [];

        // 1. 全角文字チェック（コメント・文字列・HTMLテキストを除外）
        issues = issues.concat(checkFullwidthCharacters(filename, code));

        // 2. クォート閉じ忘れチェック
        issues = issues.concat(checkUnclosedQuotes(filename, code));

        // 3. 括弧対応チェック
        issues = issues.concat(checkBracketPairs(filename, code));

        // 4. ファイルタイプ別チェック
        if (filename.endsWith('config.js')) {
            issues = issues.concat(checkConfigSchemaAndTraps(code, changedLines));
            if (issues.filter(i => i.severity === 'error').length === 0) {
                issues = issues.concat(checkJavaScriptNativeSyntax(code, changedLines, true));
            }
        } else if (filename.endsWith('.js')) {
            if (issues.filter(i => i.severity === 'error').length === 0) {
                issues = issues.concat(checkJavaScriptNativeSyntax(code, changedLines, false));
            }
        } else if (filename.endsWith('.css')) {
            issues = issues.concat(checkCSS(code));
        } else if (filename.endsWith('.html')) {
            issues = issues.concat(checkHTML(code, changedLines));
        }

        // 5. TODO警告
        const warnings = checkTodoWarnings(code);
        issues = issues.concat(warnings);

        // 差分行マーク付け
        if (changedLines && changedLines.size > 0) {
            for (const issue of issues) {
                if (changedLines.has(issue.line)) {
                    issue.isChangedByUser = true;
                }
            }
        }

        // 重複除外
        const seen = new Set();
        const unique = [];

        for (const item of issues) {
            const key = `${item.line}:${item.col}:${item.message}`;
            if (!seen.has(key)) {
                seen.add(key);
                unique.push(item);
            }
        }

        // ソート順：
        // 1. ユーザーが編集した行 (isChangedByUser) を最優先！
        // 2. エラー (severity === 'error') を警告より優先
        // 3. 行番号順
        unique.sort((a, b) => {
            if (a.isChangedByUser && !b.isChangedByUser) return -1;
            if (!a.isChangedByUser && b.isChangedByUser) return 1;

            if (a.severity === 'error' && b.severity !== 'error') return -1;
            if (a.severity !== 'error' && b.severity === 'error') return 1;

            if (a.line !== b.line) return a.line - b.line;
            return a.col - b.col;
        });

        return unique;
    }

    const Linter = {
        lint: lint,
        createIssue: createIssue,
        computeChangedLines: computeChangedLines
    };

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = Linter;
    } else {
        global.Linter = Linter;
    }

})(typeof window !== 'undefined' ? window : global);


// ============================================================================
// BUNDLED: Monaca Cloud IDE 連携ブリッジ & ドット絵モーダル
// ============================================================================
/**
 * monaca-bridge.js - Monaca Cloud IDE 連携エンジン
 * 
 * 1. Monaca の Monaco Editor を直接検知し、英語の分かりにくいエラーを消去
 * 2. 初心者向け Linter による親切な日本語エラーマーカー（行番号・波線・ヒント）をエディタに直接流し込み
 * 3. プレビュー画面上にも「⚠️ config.js のミスを検知」HUDを表示
 * 4. ドット絵エディタから Monaca エディタの config.js をワンクリック直接書き換え
 */

(function () {
    'use strict';

    // ゲーム画面上のエラーHUD要素
    let errorHudElem = null;

    function getOrCreateErrorHud() {
        if (!errorHudElem) {
            errorHudElem = document.getElementById('monaca-error-hud');
            if (!errorHudElem) {
                errorHudElem = document.createElement('div');
                errorHudElem.id = 'monaca-error-hud';
                errorHudElem.className = 'monaca-error-hud';
                errorHudElem.style.display = 'none';
                document.body.appendChild(errorHudElem);
            }
        }
        return errorHudElem;
    }

    function showInGameErrorHud(errors) {
        const hud = getOrCreateErrorHud();
        if (!errors || errors.length === 0) {
            hud.style.display = 'none';
            return;
        }

        const first = errors[0];
        const lineNum = first.line || '?';
        const title = first.title || '設定エラー';
        const msg = first.message || '';
        const hint = first.hint || '';

        hud.innerHTML = `
            <div class="monaca-hud-badge">
                <span class="hud-badge-dot">●</span>
                <span class="hud-badge-title">⚠️ config.js のミスを検知</span>
                <span class="hud-badge-line">${lineNum} 行目</span>
            </div>
            <div class="monaca-hud-body">
                <div class="monaca-hud-title">${escapeHtml(title)}</div>
                <div class="monaca-hud-msg">${escapeHtml(msg)}</div>
                ${hint ? `<div class="monaca-hud-hint">💡 <strong>ヒント:</strong> ${escapeHtml(hint)}</div>` : ''}
            </div>
            <div class="monaca-hud-footer">
                左側のエディタで修正して保存 (Ctrl+S) すると自動で再開します
            </div>
        `;
        hud.style.display = 'flex';
    }

    function hideInGameErrorHud() {
        const hud = getOrCreateErrorHud();
        hud.style.display = 'none';
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    // ─────────────────────────────────────────────
    // Monaca IDE 親ウィンドウ連携
    // ─────────────────────────────────────────────
    function initBridge() {
        // 通常の単体ブラウザ表示時のフォールバック診断
        runLocalValidation();

        try {
            if (!window.parent || window.parent === window) return;
            const parentMonaco = window.parent.monaco;
            if (!parentMonaco || !parentMonaco.editor) {
                setTimeout(initBridge, 600);
                return;
            }

            console.log('[MonacaBridge] Monaca Cloud IDE 連携が有効化されました。');

            // Monaca エディタ用のスタイルを親ページに注入（見やすいエラーマーカー）
            try {
                const parentDoc = window.parent.document;
                if (parentDoc && !parentDoc.getElementById('monaca-trial-admission-custom-css')) {
                    const style = parentDoc.createElement('style');
                    style.id = 'monaca-trial-admission-custom-css';
                    style.textContent = `
                        /* 日本語エラーマーカーのツールチップを読みやすく強調 */
                        .monaco-editor .marker.trial-admission-error {
                            background-color: rgba(255, 51, 68, 0.25) !important;
                        }
                    `;
                    parentDoc.head.appendChild(style);
                }
            } catch (e) {}

            function findConfigModel() {
                try {
                    const models = parentMonaco.editor.getModels();
                    for (const m of models) {
                        const path = (m.uri && m.uri.path) ? m.uri.path : (m.uri ? m.uri.toString() : '');
                        if (path.endsWith('config.js') || path.includes('config.js')) {
                            return m;
                        }
                    }
                } catch(e) {}
                return null;
            }

            function attachModel(model) {
                if (model._monacaBridgeAttached) return;
                model._monacaBridgeAttached = true;

                function check() {
                    try {
                        const code = model.getValue();
                        let errors = [];
                        if (window.Linter && typeof window.Linter.lint === 'function') {
                            errors = window.Linter.lint(code);
                        }

                        // Monaca 既存の JSHint / TypeScript の難解な英語エラーを消去
                        try {
                            parentMonaco.editor.setModelMarkers(model, 'jshint', []);
                            parentMonaco.editor.setModelMarkers(model, 'javascript', []);
                            parentMonaco.editor.setModelMarkers(model, 'typescript', []);
                        } catch(e) {}

                        // 親切な日本語マーカーを設定
                        const markers = errors.map(err => {
                            let sev = parentMonaco.MarkerSeverity.Error;
                            if (err.severity === 'warning') sev = parentMonaco.MarkerSeverity.Warning;
                            if (err.severity === 'info') sev = parentMonaco.MarkerSeverity.Info;

                            return {
                                startLineNumber: err.line || 1,
                                startColumn: err.column || 1,
                                endLineNumber: err.line || 1,
                                endColumn: (err.column || 1) + Math.max(1, err.length || 1),
                                message: `【${err.title || '設定ミス'}】${err.message}${err.hint ? '\n💡 ヒント: ' + err.hint : ''}`,
                                severity: sev,
                                source: '体験入学サポーター'
                            };
                        });

                        parentMonaco.editor.setModelMarkers(model, 'trial-admission-linter', markers);
                        showInGameErrorHud(errors);
                    } catch (err) {
                        console.warn('[MonacaBridge] Validation error:', err);
                    }
                }

                model.onDidChangeContent(() => {
                    check();
                });

                check();
            }

            // config.js が開かれたら即フック
            setInterval(() => {
                const model = findConfigModel();
                if (model) attachModel(model);
            }, 800);

            // ドット絵エディタから Monaca エディタの config.js を直接更新
            window.applySpriteToMonacaEditor = function(spriteKey, gridStrings) {
                const model = findConfigModel();
                if (!model) return false;

                try {
                    const code = model.getValue();
                    const rowsText = gridStrings.map(row => `            "${row}"`).join(',\n');
                    const formattedCode = '[\n' + rowsText + '\n        ]';
                    const regex = new RegExp(`(\\b${spriteKey}:\\s*)\\[[\\s\\S]*?\\]`);

                    if (regex.test(code)) {
                        const newCode = code.replace(regex, (m, head) => head + formattedCode);
                        model.setValue(newCode);
                        return true;
                    }
                } catch(e) {
                    console.error('[MonacaBridge] Failed to apply sprite to Monaca editor:', e);
                }
                return false;
            };

        } catch(e) {
            console.warn('[MonacaBridge] Init failed:', e);
        }
    }

    // ─────────────────────────────────────────────
    // ゲーム内ドット絵モーダル (Monaca / 単体実行用)
    // ─────────────────────────────────────────────
    const DEFAULT_SPRITE_TEMPLATES = {
        player: [
            "0000001000000",
            "0000011100000",
            "0000011100000",
            "0111111111110",
            "1111111111111",
            "1111111111111",
            "1111110111111",
            "1100000000011"
        ],
        squid: [
            "0000110000",
            "0001111000",
            "0011111100",
            "0110110110",
            "1111111111",
            "0001001000",
            "0010110100",
            "0101001010"
        ],
        crab: [
            "00100000100",
            "00010001000",
            "00111111100",
            "01101110110",
            "11111111111",
            "10111111101",
            "10100000101",
            "00011011000"
        ],
        octopus: [
            "000011110000",
            "011111111110",
            "111111111111",
            "111001100111",
            "111111111111",
            "000110011000",
            "001101101100",
            "110000000011"
        ],
        ufo: [
            "0000011111100000",
            "0001111111111000",
            "0011111111111100",
            "0110110110110110",
            "1111111111111111",
            "0011100110011100",
            "0001000000001000"
        ]
    };

    let modalGridData = [];
    let modalHistory = [];
    let modalRedoHistory = [];
    let modalCurrentKey = 'player';
    let modalIsDrawing = false;
    let modalDrawMode = 1;

    function initDotModal() {
        const btnOpen = document.getElementById('btn-open-dot-modal');
        const overlay = document.getElementById('dot-modal-overlay');
        const btnClose = document.getElementById('btn-close-dot-modal');
        const select = document.getElementById('modal-sprite-select');
        const chkSym = document.getElementById('modal-sprite-symmetry');
        const btnClear = document.getElementById('btn-modal-clear');
        const btnReset = document.getElementById('btn-modal-reset');
        const btnUndo = document.getElementById('btn-modal-undo');
        const btnRedo = document.getElementById('btn-modal-redo');
        const btnApply = document.getElementById('btn-modal-apply');
        const btnCopy = document.getElementById('btn-modal-copy');

        if (!overlay) return;

        function loadModalSprite(key) {
            modalCurrentKey = key;
            let lines = null;
            if (window.GameConfig && window.GameConfig.sprites && window.GameConfig.sprites[key]) {
                const s = window.GameConfig.sprites[key];
                lines = Array.isArray(s[0]) ? s[0] : s;
            }
            if (!lines) lines = DEFAULT_SPRITE_TEMPLATES[key] || DEFAULT_SPRITE_TEMPLATES.player;
            modalGridData = lines.map(row => row.split('').map(c => c === '1' ? 1 : 0));
            modalHistory = [];
            modalRedoHistory = [];
            renderModalGrid();
        }

        function renderModalGrid() {
            const grid = document.getElementById('modal-sprite-grid');
            const sizeInfo = document.getElementById('modal-size-info');
            if (!grid || modalGridData.length === 0) return;

            const rows = modalGridData.length;
            const cols = modalGridData[0].length;
            if (sizeInfo) sizeInfo.textContent = `${cols} x ${rows}`;

            grid.innerHTML = '';
            grid.style.gridTemplateColumns = `repeat(${cols}, 20px)`;
            grid.style.gridTemplateRows = `repeat(${rows}, 20px)`;

            const isSym = chkSym && chkSym.checked;
            const symCol = Math.floor((cols - 1) / 2);

            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    const cell = document.createElement('div');
                    cell.className = 'modal-sprite-cell';
                    if (isSym && c === symCol) cell.style.borderRight = '1px solid #38bdf8';
                    if (modalGridData[r][c] === 1) cell.classList.add('active');

                    cell.addEventListener('mousedown', (e) => {
                        e.preventDefault();
                        modalIsDrawing = true;
                        modalDrawMode = modalGridData[r][c] === 1 ? 0 : 1;
                        pushModalHistory();
                        applyModalPixel(r, c, modalDrawMode);
                    });
                    cell.addEventListener('mouseenter', () => {
                        if (modalIsDrawing) applyModalPixel(r, c, modalDrawMode);
                    });
                    grid.appendChild(cell);
                }
            }

            drawModalMiniPreview();
            broadcastModalSprite();
        }

        function applyModalPixel(r, c, val) {
            const cols = modalGridData[0].length;
            setModalCell(r, c, val);
            if (chkSym && chkSym.checked) {
                const mirror = cols - 1 - c;
                if (mirror !== c) setModalCell(r, mirror, val);
            }
            drawModalMiniPreview();
            broadcastModalSprite();
        }

        function setModalCell(r, c, val) {
            if (!modalGridData[r] || modalGridData[r][c] === undefined) return;
            modalGridData[r][c] = val;
            const grid = document.getElementById('modal-sprite-grid');
            if (grid) {
                const cell = grid.children[r * modalGridData[0].length + c];
                if (cell) {
                    if (val === 1) cell.classList.add('active');
                    else cell.classList.remove('active');
                }
            }
        }

        function pushModalHistory() {
            modalHistory.push(modalGridData.map(row => row.slice()));
            if (modalHistory.length > 20) modalHistory.shift();
            modalRedoHistory = [];
        }

        function drawModalMiniPreview() {
            const cvs = document.getElementById('modal-mini-canvas');
            if (!cvs || modalGridData.length === 0) return;
            const ctx = cvs.getContext('2d');
            ctx.clearRect(0, 0, cvs.width, cvs.height);

            const rows = modalGridData.length;
            const cols = modalGridData[0].length;
            const pxSize = Math.max(1, Math.min(Math.floor(cvs.width / cols), Math.floor(cvs.height / rows)));
            const startX = Math.floor((cvs.width - cols * pxSize) / 2);
            const startY = Math.floor((cvs.height - rows * pxSize) / 2);

            ctx.fillStyle = "#00FF66";
            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    if (modalGridData[r][c] === 1) {
                        ctx.fillRect(startX + c * pxSize, startY + r * pxSize, pxSize, pxSize);
                    }
                }
            }
        }

        function broadcastModalSprite() {
            if (typeof window.updateLiveSpritePreview === 'function') {
                const lines = modalGridData.map(r => r.join(''));
                window.updateLiveSpritePreview(modalCurrentKey, lines);
            }
        }

        window.addEventListener('mouseup', () => { modalIsDrawing = false; });

        btnOpen?.addEventListener('click', (e) => {
            e.stopPropagation();
            overlay.style.display = 'flex';
            loadModalSprite(select ? select.value : 'player');
        });

        btnClose?.addEventListener('click', () => {
            overlay.style.display = 'none';
        });

        select?.addEventListener('change', () => {
            loadModalSprite(select.value);
        });

        btnClear?.addEventListener('click', () => {
            pushModalHistory();
            modalGridData = modalGridData.map(row => row.map(() => 0));
            renderModalGrid();
        });

        btnReset?.addEventListener('click', () => {
            pushModalHistory();
            const tmpl = DEFAULT_SPRITE_TEMPLATES[modalCurrentKey] || DEFAULT_SPRITE_TEMPLATES.player;
            modalGridData = tmpl.map(row => row.split('').map(c => c === '1' ? 1 : 0));
            renderModalGrid();
        });

        btnUndo?.addEventListener('click', () => {
            if (modalHistory.length === 0) return;
            modalRedoHistory.push(modalGridData.map(row => row.slice()));
            modalGridData = modalHistory.pop();
            renderModalGrid();
        });

        btnRedo?.addEventListener('click', () => {
            if (modalRedoHistory.length === 0) return;
            modalHistory.push(modalGridData.map(row => row.slice()));
            modalGridData = modalRedoHistory.pop();
            renderModalGrid();
        });

        btnApply?.addEventListener('click', () => {
            const lines = modalGridData.map(r => r.join(''));
            let applied = false;
            if (typeof window.applySpriteToMonacaEditor === 'function') {
                applied = window.applySpriteToMonacaEditor(modalCurrentKey, lines);
            }
            if (applied) {
                alert('✨ Monaca の config.js に直接反映しました！\n左側のエディタを確認してください。');
            } else {
                const code = '[\n' + lines.map(l => `            "${l}"`).join(',\n') + '\n        ]';
                navigator.clipboard.writeText(code).then(() => {
                    alert('📋 ドット絵コードをコピーしました！\nconfig.js の ' + modalCurrentKey + ' 部分に貼り付けてください。');
                });
            }
        });

        btnCopy?.addEventListener('click', () => {
            const lines = modalGridData.map(r => r.join(''));
            const code = '[\n' + lines.map(l => `            "${l}"`).join(',\n') + '\n        ]';
            navigator.clipboard.writeText(code).then(() => {
                alert('📋 ドット絵コードをクリップボードにコピーしました！');
            });
        });
    }

    if (document.readyState === 'loading') {
        window.addEventListener('DOMContentLoaded', () => {
            initBridge();
            initDotModal();
        });
    } else {
        initBridge();
        initDotModal();
    }
})();

